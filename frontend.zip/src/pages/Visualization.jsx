import { useState, useEffect } from 'react'
import { Menu, Modal, Descriptions, Tag, Button, AutoComplete, message, Table } from 'antd'
import { dashboardAPI, classesAPI, subjectsAPI, tagsAPI, studentTagsAPI } from '../services/api'
import { useAuth } from '../context/AuthContext'
import ReactECharts from 'echarts-for-react'
import './Visualization.css'

const maleAvatars = ['👦', '👨‍🎓', '🧑‍🎓', '👦🏻', '👦🏼', '👦🏽']
const femaleAvatars = ['👧', '👩‍🎓', '🧒', '👧🏻', '👧🏼', '👧🏽']

function Visualization() {
  const { user } = useAuth()
  const [teacherClasses, setTeacherClasses] = useState([])
  const [classMenuItems, setClassMenuItems] = useState([])
  const [selectedClass, setSelectedClass] = useState(null)
  const [students, setStudents] = useState([])
  const [subjects, setSubjects] = useState([])
  const [classInfo, setClassInfo] = useState(null)
  const [selectedStudent, setSelectedStudent] = useState(null)
  const [studentScores, setStudentScores] = useState([])
  const [classScores, setClassScores] = useState([])
  const [showStudentScoreModal, setShowStudentScoreModal] = useState(false)
  const [showClassScoreModal, setShowClassScoreModal] = useState(false)
  const [showClassInfoModal, setShowClassInfoModal] = useState(false)
  const [showTagModal, setShowTagModal] = useState(false)
  const [taggingStudent, setTaggingStudent] = useState(null)
  const [allTags, setAllTags] = useState([])
  const [tagSearchValue, setTagSearchValue] = useState('')
  const [showReportModal, setShowReportModal] = useState(false)
  const [reportType, setReportType] = useState('')
  const [reportData, setReportData] = useState(null)
  const [showProgressRegressionModal, setShowProgressRegressionModal] = useState(false)
  const [progressRegressionData, setProgressRegressionData] = useState(null)

  useEffect(() => {
    if (user?.id) {
      fetchTeacherClasses()
    }
    subjectsAPI.list().then(res => setSubjects(res.data))
    tagsAPI.list().then(res => setAllTags(res.data))
  }, [user])

  const fetchTeacherClasses = async () => {
    try {
      const res = await classesAPI.getTeacherClasses(user.id)
      const classes = res.data
      
      // Build flat menu items (no grade grouping)
      const items = classes.map(c => ({
        key: String(c.id),
        label: c.display_name
      }))

      setClassMenuItems(items)
      setTeacherClasses(classes)

      // Auto select first class
      if (classes.length > 0) {
        setSelectedClass(classes[0].id)
      }
    } catch (err) {
      console.error('获取班级失败', err)
    }
  }

  useEffect(() => {
    if (selectedClass) {
      fetchData()
    }
  }, [selectedClass])

  const fetchData = async () => {
    try {
      const subjectId = user?.subject_id
      const [studentsRes, classInfoRes] = await Promise.all([
        dashboardAPI.getClassStudents(selectedClass, subjectId),
        dashboardAPI.getClassInfo(selectedClass, subjectId)
      ])
      // Sort students by latest score descending, students without scores go last
      const sortedStudents = [...studentsRes.data].sort((a, b) => {
        const scoreA = a.latest_score?.score
        const scoreB = b.latest_score?.score
        
        // Both have scores - sort descending
        if (scoreA !== undefined && scoreA !== null && scoreB !== undefined && scoreB !== null) {
          return scoreB - scoreA
        }
        // Only a has score - a comes first
        if (scoreA !== undefined && scoreA !== null) return -1
        // Only b has score - b comes first
        if (scoreB !== undefined && scoreB !== null) return 1
        // Neither has score - keep original order
        return 0
      })
      setStudents(sortedStudents)
      setClassInfo(classInfoRes.data)
    } catch (err) {
      console.error('获取数据失败', err)
    }
  }

  const handleStudentClick = async (student) => {
    setSelectedStudent(student)
    try {
      const subjectId = user?.subject_id
      const res = await dashboardAPI.getStudentScores(student.id, subjectId)
      setStudentScores(res.data)
    } catch (err) {
      setStudentScores([])
    }
  }

  const handleTeacherClick = async () => {
    setShowClassInfoModal(true)
    try {
      const subjectId = user?.subject_id
      const res = await dashboardAPI.getClassAvgScore(selectedClass, subjectId)
      setClassScores(res.data)
    } catch (err) {
      setClassScores([])
    }
  }

  const handleStudentScoreClick = () => {
    setShowStudentScoreModal(true)
  }

  const handleClassScoreClick = async () => {
    setShowClassScoreModal(true)
    try {
      const subjectId = user?.subject_id
      const res = await dashboardAPI.getClassAvgScore(selectedClass, subjectId)
      setClassScores(res.data)
    } catch (err) {
      setClassScores([])
    }
  }

  const handleReportClick = async (type) => {
    setReportType(type)
    setShowReportModal(true)
    try {
      const subjectId = user?.subject_id
      let res
      if (type === 'progress') {
        res = await dashboardAPI.getProgressReport(selectedClass, subjectId)
        setReportData(res.data)
      } else if (type === 'regression') {
        res = await dashboardAPI.getRegressionReport(selectedClass, subjectId)
        setReportData(res.data)
      } else if (type === 'scoreDistribution') {
        res = await dashboardAPI.getScoreDistribution(selectedClass, subjectId)
        setReportData(res.data)
      } else if (type === 'genderDistribution') {
        res = await dashboardAPI.getGenderDistribution(selectedClass, subjectId)
        setReportData(res.data)
      }
    } catch (err) {
      console.error('获取报表数据失败', err)
      message.error('获取报表数据失败')
    }
  }

  const handleProgressRegressionClick = async () => {
    setShowProgressRegressionModal(true)
    try {
      const subjectId = user?.subject_id
      const res = await dashboardAPI.getProgressRegressionSummary(selectedClass, subjectId)
      setProgressRegressionData(res.data)
    } catch (err) {
      console.error('获取进步退步分析数据失败', err)
      message.error('获取数据失败')
    }
  }

  const getAvatar = (gender, index) => {
    const avatars = gender === '男' ? maleAvatars : femaleAvatars
    return avatars[index % avatars.length]
  }

  const handleAddTag = async (studentId, tagName) => {
    if (!tagName) return
    try {
      // Find existing tag or create new one
      let tag = allTags.find(t => t.name === tagName)
      if (!tag) {
        const res = await tagsAPI.create({ name: tagName })
        tag = res.data
        setAllTags([...allTags, tag])
      }
      await studentTagsAPI.add(studentId, tag.id)
      message.success('标签添加成功')
      // Refresh student data
      fetchData()
    } catch (err) {
      message.error('添加标签失败')
    }
  }

  const handleRemoveTag = async (studentId, tagId) => {
    try {
      await studentTagsAPI.remove(studentId, tagId)
      message.success('标签移除成功')
      fetchData()
    } catch (err) {
      message.error('移除标签失败')
    }
  }

  const handleOpenTagModal = (student) => {
    setTaggingStudent(student)
    setTagSearchValue('')
    setShowTagModal(true)
  }

  const tagOptions = allTags.map(t => ({ value: t.name, label: t.name }))

  const progressColumns = [
    { title: '姓名', dataIndex: 'name', key: 'name' },
    { title: '性别', dataIndex: 'gender', key: 'gender' },
    { title: '最近分数', dataIndex: 'latest_score', key: 'latest_score' },
    { title: '上次分数', dataIndex: 'previous_score', key: 'previous_score' },
    { title: '进步分数', dataIndex: 'diff', key: 'diff', render: (val) => <span style={{ color: '#52c41a', fontWeight: 'bold' }}>+{val}</span> }
  ]

  const regressionColumns = [
    { title: '姓名', dataIndex: 'name', key: 'name' },
    { title: '性别', dataIndex: 'gender', key: 'gender' },
    { title: '最近分数', dataIndex: 'latest_score', key: 'latest_score' },
    { title: '上次分数', dataIndex: 'previous_score', key: 'previous_score' },
    { title: '退步分数', dataIndex: 'diff', key: 'diff', render: (val) => <span style={{ color: '#ff4d4f', fontWeight: 'bold' }}>{val}</span> }
  ]

  // Fixed color mapping for score ranges
  const scoreRangeColors = {
    '60分以下': '#ff4d4f',
    '60-70分': '#faad14',
    '71-80分': '#1890ff',
    '81-90分': '#52c41a',
    '91-100分': '#722ed1'
  }

  const scoreDistributionChart = reportData ? {
    title: { text: `成绩分布分析 (${reportData.exam_date || ''})`, left: 'center', top: '1%' },
    tooltip: { 
      trigger: 'item', 
      formatter: (params) => {
        const hasData = reportData.distribution && reportData.distribution.length > 0
        if (!hasData) {
          return `${params.name}: 0人 (0%)`
        }
        return `${params.name}: ${params.value}人 (${params.percent}%)`
      }
    },
    legend: { bottom: '5%' },
    series: [{
      type: 'pie',
      radius: ['40%', '70%'],
      avoidLabelOverlap: false,
      itemStyle: { borderRadius: 10, borderColor: '#fff', borderWidth: 2 },
      label: { 
        show: true, 
        position: 'outside', 
        formatter: (params) => {
          const hasData = reportData.distribution && reportData.distribution.length > 0
          return hasData ? `${params.name}: ${params.percent}%` : `${params.name}: 0%`
        }
      },
      emphasis: { label: { show: true, fontSize: 20, fontWeight: 'bold' } },
      data: reportData.distribution && reportData.distribution.length > 0
        ? reportData.distribution.map(d => ({ 
            value: d.count, 
            name: d.range,
            itemStyle: { color: scoreRangeColors[d.range] || '#999' }
          }))
        : Object.entries(scoreRangeColors).map(([range, color]) => ({
            value: 1,
            name: range,
            itemStyle: { color }
          }))
    }]
  } : null

  const genderDistributionChart = reportData?.distribution ? {
    title: { text: `性别分布分析 (${reportData.exam_date || ''})`, left: 'center' },
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    legend: { bottom: '5%' },
    grid: { left: '3%', right: '4%', bottom: '15%', containLabel: true },
    xAxis: { type: 'category', data: reportData.distribution.map(d => d.range) },
    yAxis: { type: 'value' },
    series: [
      { name: '男生', type: 'bar', data: reportData.distribution.map(d => d.male), itemStyle: { color: '#1890ff' } },
      { name: '女生', type: 'bar', data: reportData.distribution.map(d => d.female), itemStyle: { color: '#ff4d4f' } }
    ]
  } : null

  const progressRegressionChart = progressRegressionData ? {
    title: { 
      text: `进步与退步分析 (${progressRegressionData.latest_date || ''})`, 
      subtext: `对比上次考试: ${progressRegressionData.previous_date || ''}`,
      left: 'center' 
    },
    tooltip: { trigger: 'item', formatter: '{b}: {c}人 ({d}%)' },
    legend: { bottom: '5%' },
    series: [{
      type: 'pie',
      radius: ['40%', '70%'],
      avoidLabelOverlap: false,
      itemStyle: { borderRadius: 10, borderColor: '#fff', borderWidth: 2 },
      label: { show: true, formatter: '{b}: {c}人' },
      emphasis: { label: { show: true, fontSize: 16, fontWeight: 'bold' } },
      data: [
        { value: progressRegressionData.progress_count, name: '进步', itemStyle: { color: '#52c41a' } },
        { value: progressRegressionData.regression_count, name: '退步', itemStyle: { color: '#ff4d4f' } },
        { value: progressRegressionData.stable_count, name: '持平', itemStyle: { color: '#faad14' } }
      ]
    }]
  } : null

  const studentScoreChart = {
    title: { text: '成绩趋势', left: 'center' },
    tooltip: { trigger: 'axis' },
    xAxis: { type: 'category', data: studentScores.map(s => s.date).reverse() },
    yAxis: { type: 'value' },
    series: [{
      data: studentScores.map(s => s.score).reverse(),
      type: 'line',
      smooth: true,
      itemStyle: { color: '#1890ff' }
    }]
  }

  const classScoreChart = {
    title: { text: '班级平均成绩趋势', left: 'center' },
    tooltip: { trigger: 'axis' },
    xAxis: { type: 'category', data: classScores.map(s => s.date).reverse() },
    yAxis: { type: 'value' },
    series: [{
      data: classScores.map(s => s.avg_score).reverse(),
      type: 'line',
      smooth: true,
      itemStyle: { color: '#52c41a' }
    }]
  }

  return (
    <div className="visualization-container">
      {/* Top class menu */}
      <div className="class-menu-bar">
        <Menu
          mode="horizontal"
          selectedKeys={[String(selectedClass)]}
          items={classMenuItems}
          onClick={({ key }) => setSelectedClass(Number(key))}
          className="class-menu"
        />
      </div>

      {/* Content area */}
      <div className="class-content">
        {selectedClass && classInfo && (
          <>
            <div className="classroom-header">
              <div className="class-info">
                <span>总人数: {classInfo.total_students}</span>
                <span>男生: {classInfo.male_count}</span>
                <span>女生: {classInfo.female_count}</span>
                {classInfo.latest_avg_score && (
                  <span className="latest-avg-score">
                    最近平均分: <strong>{classInfo.latest_avg_score.score.toFixed(1)}</strong> |
                    <span className="score-stats">
                      最高分: <strong>{classInfo.latest_avg_score.max_score}</strong> | 
                      最低分: <strong>{classInfo.latest_avg_score.min_score}</strong> | 
                      中位数: <strong>{classInfo.latest_avg_score.median_score}</strong> | 
                      标准差: <strong>{classInfo.latest_avg_score.std_dev}</strong>
                    </span>
                    <span className="score-date">({classInfo.latest_avg_score.exam_date}) </span>
                  </span>
                )}
                <div className="report-buttons">
                  <Button size="small" onClick={handleClassScoreClick}>查看平均成绩</Button>
                  <Button size="small" onClick={() => handleReportClick('progress')}>进步前10</Button>
                  <Button size="small" onClick={() => handleReportClick('regression')}>退步前10</Button>
                  <Button size="small" onClick={handleProgressRegressionClick}>进步与退步分析</Button>
                  <Button size="small" onClick={() => handleReportClick('scoreDistribution')}>成绩分布分析</Button>
                  <Button size="small" onClick={() => handleReportClick('genderDistribution')}>性别分布分析</Button>
                </div>
              </div>
            </div>

            <div className="classroom">
              {students.map((student, index) => (
                <div
                  key={student.id}
                  className="student-card"
                  onClick={() => handleStudentClick(student)}
                >
                  <div className="student-card-header">
                    <div className="student-avatar">
                      {getAvatar(student.gender, index)}
                    </div>
                    {student.latest_score && (
                      <div className="student-latest-score">
                        <span className="score-value">{student.latest_score.score}</span>
                      </div>
                    )}
                  </div>
                  <div className="student-name">{student.name}</div>
                  <div className="student-tags">
                    {student.tags?.map(t => (
                      <Tag
                        key={t.id}
                        closable
                        onClose={(e) => {
                          e.stopPropagation()
                          handleRemoveTag(student.id, t.id)
                        }}
                      >
                        {t.name}
                      </Tag>
                    ))}
                    <Tag
                      className="add-tag-btn"
                      onClick={(e) => {
                        e.stopPropagation()
                        handleOpenTagModal(student)
                      }}
                    >
                      +
                    </Tag>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Student Info Modal - No tag editing */}
      <Modal
        title="学生信息"
        open={!!selectedStudent}
        onCancel={() => setSelectedStudent(null)}
        footer={[
          <Button key="scores" type="primary" onClick={handleStudentScoreClick}>
            查看成绩
          </Button>
        ]}
      >
        {selectedStudent && (
          <Descriptions column={1} bordered>
            <Descriptions.Item label="姓名">{selectedStudent.name}</Descriptions.Item>
            <Descriptions.Item label="性别">{selectedStudent.gender}</Descriptions.Item>
            <Descriptions.Item label="年龄">{selectedStudent.age}</Descriptions.Item>
            <Descriptions.Item label="身高">{selectedStudent.height} cm</Descriptions.Item>
            <Descriptions.Item label="体重">{selectedStudent.weight} kg</Descriptions.Item>
            <Descriptions.Item label="爱好">{selectedStudent.hobbies}</Descriptions.Item>
            <Descriptions.Item label="好友">{selectedStudent.friends}</Descriptions.Item>
            <Descriptions.Item label="标签">
              {selectedStudent.tags?.map(t => <Tag key={t.id}>{t.name}</Tag>)}
            </Descriptions.Item>
          </Descriptions>
        )}
      </Modal>

      {/* Student Score Trend Modal */}
      <Modal
        title="成绩趋势"
        open={showStudentScoreModal}
        onCancel={() => setShowStudentScoreModal(false)}
        footer={null}
        width={600}
      >
        {studentScores.length > 0 ? (
          <ReactECharts option={studentScoreChart} style={{ height: 300 }} />
        ) : (
          <p>暂无成绩数据</p>
        )}
      </Modal>

      {/* Class Score Trend Modal */}
      <Modal
        title="班级平均成绩趋势"
        open={showClassScoreModal}
        onCancel={() => setShowClassScoreModal(false)}
        footer={null}
        width={600}
      >
        {classScores.length > 0 ? (
          <ReactECharts option={classScoreChart} style={{ height: 300 }} />
        ) : (
          <p>暂无成绩数据</p>
        )}
      </Modal>

      {/* Tag Modal */}
      <Modal
        title="添加标签"
        open={showTagModal}
        onCancel={() => setShowTagModal(false)}
        footer={null}
      >
        <p>为 <strong>{taggingStudent?.name}</strong> 添加标签：</p>
        <AutoComplete
          style={{ width: '100%' }}
          options={tagOptions}
          value={tagSearchValue}
          onChange={setTagSearchValue}
          onSelect={(value) => {
            handleAddTag(taggingStudent.id, value)
            setShowTagModal(false)
          }}
          placeholder="输入或选择标签"
        >
          <input
            style={{ padding: '8px', marginTop: 8 }}
            onPressEnter={() => {
              if (tagSearchValue) {
                handleAddTag(taggingStudent.id, tagSearchValue)
                setShowTagModal(false)
              }
            }}
          />
        </AutoComplete>
        <div style={{ marginTop: 16 }}>
          <p>已有标签：</p>
          {allTags.map(t => (
            <Tag
              key={t.id}
              style={{ cursor: 'pointer', marginBottom: 8 }}
              onClick={() => {
                handleAddTag(taggingStudent.id, t.name)
                setShowTagModal(false)
              }}
            >
              {t.name}
            </Tag>
          ))}
        </div>
      </Modal>

      {/* Report Modal */}
      <Modal
        title={
          reportType === 'progress' ? '进步前10名' :
          reportType === 'regression' ? '退步前10名' :
          reportType === 'scoreDistribution' ? '成绩分布分析' :
          reportType === 'genderDistribution' ? '性别分布分析' : '报表'
        }
        open={showReportModal}
        onCancel={() => setShowReportModal(false)}
        footer={null}
        width={700}
      >
        {reportData && (
          <>
            {reportType === 'progress' && (
              <Table
                columns={progressColumns}
                dataSource={Array.isArray(reportData) ? reportData : []}
                rowKey="name"
                pagination={false}
                size="small"
              />
            )}
            {reportType === 'regression' && (
              <Table
                columns={regressionColumns}
                dataSource={Array.isArray(reportData) ? reportData : []}
                rowKey="name"
                pagination={false}
                size="small"
              />
            )}
            {reportType === 'scoreDistribution' && scoreDistributionChart && (
              <ReactECharts option={scoreDistributionChart} style={{ height: 400 }} />
            )}
            {reportType === 'genderDistribution' && genderDistributionChart && (
              <ReactECharts option={genderDistributionChart} style={{ height: 400 }} />
            )}
            {((reportType === 'scoreDistribution' && !scoreDistributionChart) ||
              (reportType === 'genderDistribution' && !genderDistributionChart)) && (
              <p>暂无数据</p>
            )}
          </>
        )}
      </Modal>

      {/* Progress/Regression Analysis Modal */}
      <Modal
        title="进步与退步分析"
        open={showProgressRegressionModal}
        onCancel={() => setShowProgressRegressionModal(false)}
        footer={null}
        width={700}
      >
        {progressRegressionData && (
          <>
            <div style={{ marginBottom: 24, display: 'flex', justifyContent: 'space-around', padding: '16px', background: '#f5f5f5', borderRadius: '8px' }}>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: 32, fontWeight: 'bold', color: '#52c41a' }}>{progressRegressionData.progress_count}</div>
                <div style={{ fontSize: 14, color: '#666' }}>进步人数</div>
              </div>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: 32, fontWeight: 'bold', color: '#ff4d4f' }}>{progressRegressionData.regression_count}</div>
                <div style={{ fontSize: 14, color: '#666' }}>退步人数</div>
              </div>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: 32, fontWeight: 'bold', color: '#faad14' }}>{progressRegressionData.stable_count}</div>
                <div style={{ fontSize: 14, color: '#666' }}>持平人数</div>
              </div>
            </div>
            {progressRegressionChart ? (
              <ReactECharts option={progressRegressionChart} style={{ height: 400 }} />
            ) : (
              <p>暂无数据</p>
            )}
          </>
        )}
      </Modal>
    </div>
  )
}

export default Visualization
