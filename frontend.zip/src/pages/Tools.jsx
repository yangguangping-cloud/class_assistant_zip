import { Routes, Route, useNavigate, useLocation } from 'react-router-dom'
import { Menu } from 'antd'
import { FilePdfOutlined } from '@ant-design/icons'
import PdfToWord from './tools/PdfToWord'
import './Tools.css'

const menuItems = [
  { key: '/tools/pdf2docx', icon: <FilePdfOutlined />, label: 'PDF转Word' }
]

function Tools() {
  const navigate = useNavigate()
  const location = useLocation()

  return (
    <div className="tools-container">
      <Menu
        mode="horizontal"
        selectedKeys={[location.pathname]}
        items={menuItems}
        onClick={({ key }) => navigate(key)}
        style={{ marginBottom: 16 }}
      />
      <Routes>
        <Route index element={<PdfToWord />} />
        <Route path="pdf2docx" element={<PdfToWord />} />
      </Routes>
    </div>
  )
}

export default Tools
