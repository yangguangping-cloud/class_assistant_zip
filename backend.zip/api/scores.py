from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session
from typing import List
from utils.database import get_db
from entity import models, schemas
import pandas as pd
import io

router = APIRouter()


@router.get("", response_model=List[schemas.ScoreResponse])
def get_scores(db: Session = Depends(get_db)):
    return db.query(models.Score).all()


@router.get("/student/{student_id}", response_model=List[schemas.ScoreResponse])
def get_student_scores(student_id: int, db: Session = Depends(get_db)):
    return db.query(models.Score).filter(models.Score.student_id == student_id).order_by(
        models.Score.exam_date.desc()).all()


@router.get("/class/{class_id}/subject/{subject_id}")
def get_class_scores(class_id: int, subject_id: int, db: Session = Depends(get_db)):
    return db.query(models.Score).filter(
        models.Score.class_id == class_id,
        models.Score.subject_id == subject_id
    ).order_by(models.Score.exam_date.desc()).all()


@router.post("", response_model=schemas.ScoreResponse)
def create_score(score: schemas.ScoreCreate, db: Session = Depends(get_db)):
    db_score = models.Score(**score.dict())
    db.add(db_score)
    db.commit()
    db.refresh(db_score)
    return db_score


@router.put("/{score_id}", response_model=schemas.ScoreResponse)
def update_score(score_id: int, score: schemas.ScoreCreate, db: Session = Depends(get_db)):
    db_score = db.query(models.Score).filter(models.Score.id == score_id).first()
    if not db_score:
        raise HTTPException(status_code=404, detail="Score not found")
    for key, value in score.dict().items():
        setattr(db_score, key, value)
    db.commit()
    db.refresh(db_score)
    return db_score


@router.post("/import")
async def import_scores(file: UploadFile = File(...), db: Session = Depends(get_db)):
    try:
        content = await file.read()
        df = pd.read_excel(io.BytesIO(content))
        scores = []
        class_dict = {}

        subject_objs = db.query(models.Subject).all()
        subject_dict = {s.name: s.id for s in subject_objs}

        for _, row in df.iterrows():
            if row["班级"] not in class_dict:
                class_obj = db.query(models.Class).filter(
                    models.Class.display_name == row["班级"]
                ).first()
                class_id = class_obj.id
                class_dict[row["班级"]] = class_id
            else:
                class_id = class_dict[row["班级"]]

            student_obj = db.query(models.Student).filter(
                models.Student.name == row["姓名"],
                models.Student.class_id == class_id
            ).first()

            score = models.Score(
                student_id=student_obj.id,
                class_id=class_id,
                subject_id=subject_dict[row['学科']],
                score_type=row['考试类型'],
                score=row['成绩'],
                exam_date=row['考试日期']
            )
            scores.append(score)
        db.bulk_save_objects(scores)
        db.commit()
        return {"message": f"Successfully imported {len(scores)} scores"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
