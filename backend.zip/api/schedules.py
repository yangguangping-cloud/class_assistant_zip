from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from utils.database import get_db
from entity import models, schemas

router = APIRouter()


@router.get("", response_model=List[schemas.ScheduleResponse])
def get_schedules(db: Session = Depends(get_db)):
    schedules = db.query(models.Schedule).all()
    result = []
    for s in schedules:
        class_display_name = s.class_.display_name if s.class_ and s.class_.display_name else s.class_.name if s.class_ else None
        result.append({
            "id": s.id,
            "class_id": s.class_id,
            "teacher_id": s.teacher_id,
            "subject_id": s.subject_id,
            "day_of_week": s.day_of_week,
            "time_slot": s.time_slot,
            "start_time": s.start_time,
            "end_time": s.end_time,
            "created_at": s.created_at,
            "class_name": class_display_name,
            "teacher_name": s.teacher.name if s.teacher else None,
            "subject_name": s.subject.name if s.subject else None
        })
    return result


@router.get("/teacher/{teacher_id}", response_model=List[schemas.ScheduleResponse])
def get_teacher_schedules(teacher_id: int, db: Session = Depends(get_db)):
    schedules = db.query(models.Schedule).filter(models.Schedule.teacher_id == teacher_id).all()
    result = []
    for s in schedules:
        class_display_name = s.class_.display_name if s.class_ and s.class_.display_name else s.class_.name if s.class_ else None
        result.append({
            "id": s.id,
            "class_id": s.class_id,
            "teacher_id": s.teacher_id,
            "subject_id": s.subject_id,
            "day_of_week": s.day_of_week,
            "time_slot": s.time_slot,
            "start_time": s.start_time,
            "end_time": s.end_time,
            "created_at": s.created_at,
            "class_name": class_display_name,
            "teacher_name": s.teacher.name if s.teacher else None,
            "subject_name": s.subject.name if s.subject else None
        })
    return result


@router.post("", response_model=schemas.ScheduleResponse)
def create_schedule(schedule: schemas.ScheduleCreate, db: Session = Depends(get_db)):
    db_schedule = models.Schedule(**schedule.dict())
    db.add(db_schedule)
    db.commit()
    db.refresh(db_schedule)
    return db_schedule


@router.put("/{schedule_id}", response_model=schemas.ScheduleResponse)
def update_schedule(schedule_id: int, schedule: schemas.ScheduleUpdate, db: Session = Depends(get_db)):
    db_schedule = db.query(models.Schedule).filter(models.Schedule.id == schedule_id).first()
    if not db_schedule:
        raise HTTPException(status_code=404, detail="Schedule not found")
    for key, value in schedule.dict().items():
        setattr(db_schedule, key, value)
    db.commit()
    db.refresh(db_schedule)
    return db_schedule


@router.delete("/{schedule_id}")
def delete_schedule(schedule_id: int, db: Session = Depends(get_db)):
    db_schedule = db.query(models.Schedule).filter(models.Schedule.id == schedule_id).first()
    if not db_schedule:
        raise HTTPException(status_code=404, detail="Schedule not found")
    db.delete(db_schedule)
    db.commit()
    return {"message": "Schedule deleted"}
