from fastapi import APIRouter

from . import auth, grades, subjects, classes, users, students, scores, tags, schedules, dashboard, grade_analysis, pdf2docx

api_router = APIRouter()

# Include all routers
api_router.include_router(auth.router, prefix="/api/auth", tags=["认证"])
api_router.include_router(grades.router, prefix="/api/grades", tags=["年级"])
api_router.include_router(subjects.router, prefix="/api/subjects", tags=["科目"])
api_router.include_router(classes.router, prefix="/api/classes", tags=["班级"])
api_router.include_router(users.router, prefix="/api/users", tags=["用户"])
api_router.include_router(students.router, prefix="/api/students", tags=["学生"])
api_router.include_router(scores.router, prefix="/api/scores", tags=["成绩"])
api_router.include_router(tags.router, prefix="/api/tags", tags=["标签"])
api_router.include_router(schedules.router, prefix="/api/schedules", tags=["课表"])
api_router.include_router(dashboard.router, prefix="/api/dashboard", tags=["仪表盘"])
api_router.include_router(grade_analysis.router, prefix="/api/grade-analysis", tags=["年级分析"])
api_router.include_router(pdf2docx.router, prefix="/api/pdf2docx", tags=["PDF转Word"])
