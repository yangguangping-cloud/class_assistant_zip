from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
from utils.database import get_db
from entity import models, schemas
from typing import Optional
import statistics
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from utils.auth_utils import decode_access_token

router = APIRouter()

security = HTTPBearer()


def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security), db: Session = Depends(get_db)):
    token = credentials.credentials
    payload = decode_access_token(token)
    if payload is None:
        raise HTTPException(status_code=401, detail="Invalid authentication credentials")
    user = db.query(models.User).filter(models.User.id == payload.get("user_id")).first()
    if user is None:
        raise HTTPException(status_code=401, detail="User not found")
    return user


@router.get("/class/{class_id}")
def get_class_dashboard(class_id: int, subject_id: Optional[int] = None, db: Session = Depends(get_db)):
    class_item = db.query(models.Class).filter(models.Class.id == class_id).first()
    if not class_item:
        raise HTTPException(status_code=404, detail="Class not found")

    students = db.query(models.Student).filter(models.Student.class_id == class_id).all()
    male_count = sum(1 for s in students if s.gender == "男")
    female_count = sum(1 for s in students if s.gender == "女")

    # Get latest class average score and statistics
    latest_avg_score = None
    score_query = db.query(
        models.Score.exam_date,
        func.avg(models.Score.score).label('avg_score')
    ).filter(models.Score.class_id == class_id)
    
    if subject_id:
        score_query = score_query.filter(models.Score.subject_id == subject_id)
    
    latest_score_record = score_query.group_by(models.Score.exam_date).order_by(
        models.Score.exam_date.desc()
    ).first()
    
    if latest_score_record:
        # Get all scores for the latest exam to calculate statistics
        latest_date = latest_score_record.exam_date
        scores_query = db.query(models.Score.score).filter(
            models.Score.class_id == class_id,
            models.Score.exam_date == latest_date
        )
        if subject_id:
            scores_query = scores_query.filter(models.Score.subject_id == subject_id)
        
        scores = [s.score for s in scores_query.all()]
        
        if scores:
            max_score = max(scores)
            min_score = min(scores)
            median_score = statistics.median(scores)
            std_dev = statistics.stdev(scores) if len(scores) > 1 else 0
            
            latest_avg_score = {
                "score": float(latest_score_record.avg_score),
                "exam_date": str(latest_score_record.exam_date),
                "max_score": max_score,
                "min_score": min_score,
                "median_score": round(median_score, 2),
                "std_dev": round(std_dev, 2)
            }

    return {
        "class_name": class_item.display_name if class_item.display_name else class_item.name,
        "total_students": len(students),
        "male_count": male_count,
        "female_count": female_count,
        "teacher_name": class_item.teacher.name if class_item.teacher else None,
        "latest_avg_score": latest_avg_score
    }


@router.get("/class/{class_id}/average-score")
def get_class_average_score(class_id: int, subject_id: Optional[int] = None, db: Session = Depends(get_db)):
    query = db.query(
        models.Score.exam_date,
        func.avg(models.Score.score).label('avg_score')
    ).filter(models.Score.class_id == class_id)

    if subject_id:
        query = query.filter(models.Score.subject_id == subject_id)

    scores = query.group_by(models.Score.exam_date).order_by(models.Score.exam_date.desc()).limit(6).all()
    return [{"date": str(s.exam_date), "avg_score": round(float(s.avg_score), 2)} for s in scores]


@router.get("/student/{student_id}/scores")
def get_student_score_trend(student_id: int, subject_id: Optional[int] = None, db: Session = Depends(get_db)):
    query = db.query(models.Score).filter(models.Score.student_id == student_id)

    if subject_id:
        query = query.filter(models.Score.subject_id == subject_id)

    scores = query.order_by(models.Score.exam_date.desc()).limit(6).all()
    return [{
        "date": str(s.exam_date),
        "score": s.score,
        "score_type": s.score_type,
        "subject_name": s.subject.name if s.subject else None
    } for s in scores]


@router.get("/class/{class_id}/students")
def get_class_students(class_id: int, subject_id: Optional[int] = None, db: Session = Depends(get_db)):
    students = db.query(models.Student).filter(models.Student.class_id == class_id).all()
    result = []
    for s in students:
        tags = db.query(models.Tag).join(models.StudentTag).filter(models.StudentTag.student_id == s.id
        ).all()
        
        # Get latest score for this student
        latest_score = None
        score_query = db.query(models.Score).filter(
            models.Score.student_id == s.id
        )
        if subject_id:
            score_query = score_query.filter(models.Score.subject_id == subject_id)
        latest_score_record = score_query.order_by(models.Score.exam_date.desc()).first()
        if latest_score_record:
            latest_score = {
                "score": latest_score_record.score,
                "exam_date": str(latest_score_record.exam_date),
                "score_type": latest_score_record.score_type
            }
        
        result.append({
            "id": s.id,
            "name": s.name,
            "gender": s.gender,
            "age": s.age,
            "active": s.active,
            "height": s.height,
            "weight": s.weight,
            "hobbies": s.hobbies,
            "friends": s.friends,
            "tags": [{"id": t.id, "name": t.name} for t in tags],
            "latest_score": latest_score
        })
    return result


@router.get("/current-schedule")
def get_current_schedule(current_user: models.User = Depends(get_current_user), db: Session = Depends(get_db)):
    # Return ALL schedules for the teacher, not just today
    schedules = db.query(models.Schedule).filter(
        models.Schedule.teacher_id == current_user.id
    ).all()

    result = []
    for s in schedules:
        class_display_name = s.class_.display_name if s.class_ and s.class_.display_name else s.class_.name if s.class_ else None
        result.append({
            "id": s.id,
            "class_id": s.class_id,
            "teacher_id": s.teacher_id,
            "subject_id": s.subject_id,
            "day_of_week": s.day_of_week,
            "time_slot": s.time_slot,
            "start_time": s.start_time,
            "end_time": s.end_time,
            "created_at": s.created_at,
            "class_name": class_display_name,
            "teacher_name": s.teacher.name if s.teacher else None,
            "subject_name": s.subject.name if s.subject else None
        })

    return result


@router.get("/class/{class_id}/progress-report")
def get_progress_report(class_id: int, subject_id: Optional[int] = None, db: Session = Depends(get_db)):
    """Get top 10 students with most improved scores"""
    # Find latest exam date for this class and subject
    latest_exam_query = db.query(models.Score.exam_date).filter(
        models.Score.class_id == class_id
    )
    if subject_id:
        latest_exam_query = latest_exam_query.filter(models.Score.subject_id == subject_id)
    
    latest_exam_date = latest_exam_query.order_by(models.Score.exam_date.desc()).first()
    if not latest_exam_date:
        return []
    latest_exam_date = latest_exam_date[0]
    
    # Find previous exam date
    prev_exam_query = db.query(models.Score.exam_date).filter(
        models.Score.class_id == class_id,
        models.Score.exam_date < latest_exam_date
    )
    if subject_id:
        prev_exam_query = prev_exam_query.filter(models.Score.subject_id == subject_id)
        
    prev_exam_date = prev_exam_query.order_by(models.Score.exam_date.desc()).first()
    if not prev_exam_date:
        return []
    prev_exam_date = prev_exam_date[0]
    
    # Get scores for these two dates
    students = db.query(models.Student).filter(models.Student.class_id == class_id).all()
    progress_list = []
    
    for s in students:
        latest_score = db.query(models.Score).filter(
            models.Score.student_id == s.id,
            models.Score.exam_date == latest_exam_date
        ).first()
        
        prev_score = db.query(models.Score).filter(
            models.Score.student_id == s.id,
            models.Score.exam_date == prev_exam_date
        ).first()
        
        if latest_score and prev_score:
            diff = round(latest_score.score - prev_score.score, 2)
            if diff > 0:  # Only include students with positive progress
                progress_list.append({
                    "name": s.name,
                    "gender": s.gender,
                    "latest_score": latest_score.score,
                    "previous_score": prev_score.score,
                    "diff": diff,
                    "latest_date": str(latest_exam_date),
                    "previous_date": str(prev_exam_date)
                })
            
    progress_list.sort(key=lambda x: x["diff"], reverse=True)
    return progress_list[:10]


@router.get("/class/{class_id}/regression-report")
def get_regression_report(class_id: int, subject_id: Optional[int] = None, db: Session = Depends(get_db)):
    """Get top 10 students with most regressed scores"""
    # Find latest exam date for this class and subject
    latest_exam_query = db.query(models.Score.exam_date).filter(
        models.Score.class_id == class_id
    )
    if subject_id:
        latest_exam_query = latest_exam_query.filter(models.Score.subject_id == subject_id)
    
    latest_exam_date = latest_exam_query.order_by(models.Score.exam_date.desc()).first()
    if not latest_exam_date:
        return []
    latest_exam_date = latest_exam_date[0]
    
    # Find previous exam date
    prev_exam_query = db.query(models.Score.exam_date).filter(
        models.Score.class_id == class_id,
        models.Score.exam_date < latest_exam_date
    )
    if subject_id:
        prev_exam_query = prev_exam_query.filter(models.Score.subject_id == subject_id)
        
    prev_exam_date = prev_exam_query.order_by(models.Score.exam_date.desc()).first()
    if not prev_exam_date:
        return []
    prev_exam_date = prev_exam_date[0]
    
    # Get scores for these two dates
    students = db.query(models.Student).filter(models.Student.class_id == class_id).all()
    regression_list = []
    
    for s in students:
        latest_score = db.query(models.Score).filter(
            models.Score.student_id == s.id,
            models.Score.exam_date == latest_exam_date
        ).first()
        
        prev_score = db.query(models.Score).filter(
            models.Score.student_id == s.id,
            models.Score.exam_date == prev_exam_date
        ).first()
        
        if latest_score and prev_score:
            diff = round(latest_score.score - prev_score.score, 2)
            if diff < 0:  # Only include students with negative regression
                regression_list.append({
                    "name": s.name,
                    "gender": s.gender,
                    "latest_score": latest_score.score,
                    "previous_score": prev_score.score,
                    "diff": diff,
                    "latest_date": str(latest_exam_date),
                    "previous_date": str(prev_exam_date)
                })
            
    regression_list.sort(key=lambda x: x["diff"])
    return regression_list[:10]


@router.get("/class/{class_id}/score-distribution")
def get_score_distribution(class_id: int, subject_id: Optional[int] = None, db: Session = Depends(get_db)):
    """Get score distribution pie chart data"""
    # Get latest exam date for this class and subject
    score_query = db.query(models.Score).filter(models.Score.class_id == class_id)
    if subject_id:
        score_query = score_query.filter(models.Score.subject_id == subject_id)
    
    latest_exam = score_query.order_by(models.Score.exam_date.desc()).first()
    if not latest_exam:
        return {"distribution": [], "exam_date": None}
    
    latest_date = latest_exam.exam_date
    
    # Get all scores for the latest exam
    scores = db.query(models.Score).filter(
        models.Score.class_id == class_id,
        models.Score.exam_date == latest_date
    )
    if subject_id:
        scores = scores.filter(models.Score.subject_id == subject_id)
    scores = scores.all()
    
    distribution = [
        {"range": "60分以下", "count": 0},
        {"range": "60-70分", "count": 0},
        {"range": "71-80分", "count": 0},
        {"range": "81-90分", "count": 0},
        {"range": "91-100分", "count": 0}
    ]
    
    for sc in scores:
        score = sc.score
        if score < 60:
            distribution[0]["count"] += 1
        elif score <= 70:
            distribution[1]["count"] += 1
        elif score <= 80:
            distribution[2]["count"] += 1
        elif score <= 90:
            distribution[3]["count"] += 1
        else:
            distribution[4]["count"] += 1
    
    return {"distribution": distribution, "exam_date": str(latest_date)}


@router.get("/class/{class_id}/progress-regression-summary")
def get_progress_regression_summary(class_id: int, subject_id: Optional[int] = None, db: Session = Depends(get_db)):
    """Get summary of progress, regression, and stable students"""
    # Find latest exam date for this class and subject
    latest_exam_query = db.query(models.Score.exam_date).filter(
        models.Score.class_id == class_id
    )
    if subject_id:
        latest_exam_query = latest_exam_query.filter(models.Score.subject_id == subject_id)
    
    latest_exam_date = latest_exam_query.order_by(models.Score.exam_date.desc()).first()
    if not latest_exam_date:
        return {"progress_count": 0, "regression_count": 0, "stable_count": 0, "distribution": []}
    latest_exam_date = latest_exam_date[0]
    
    # Find previous exam date
    prev_exam_query = db.query(models.Score.exam_date).filter(
        models.Score.class_id == class_id,
        models.Score.exam_date < latest_exam_date
    )
    if subject_id:
        prev_exam_query = prev_exam_query.filter(models.Score.subject_id == subject_id)
        
    prev_exam_date = prev_exam_query.order_by(models.Score.exam_date.desc()).first()
    if not prev_exam_date:
        return {"progress_count": 0, "regression_count": 0, "stable_count": 0, "distribution": []}
    prev_exam_date = prev_exam_date[0]
    
    # Get scores for these two dates
    students = db.query(models.Student).filter(models.Student.class_id == class_id).all()
    
    progress_count = 0
    regression_count = 0
    stable_count = 0
    
    distribution = []
    
    for s in students:
        latest_score = db.query(models.Score).filter(
            models.Score.student_id == s.id,
            models.Score.exam_date == latest_exam_date
        ).first()
        
        prev_score = db.query(models.Score).filter(
            models.Score.student_id == s.id,
            models.Score.exam_date == prev_exam_date
        ).first()
        
        if latest_score and prev_score:
            diff = round(latest_score.score - prev_score.score, 2)
            if diff > 0:
                progress_count += 1
                distribution.append({
                    "name": s.name,
                    "gender": s.gender,
                    "latest_score": latest_score.score,
                    "previous_score": prev_score.score,
                    "diff": diff,
                    "category": "进步"
                })
            elif diff < 0:
                regression_count += 1
                distribution.append({
                    "name": s.name,
                    "gender": s.gender,
                    "latest_score": latest_score.score,
                    "previous_score": prev_score.score,
                    "diff": diff,
                    "category": "退步"
                })
            else:
                stable_count += 1
                distribution.append({
                    "name": s.name,
                    "gender": s.gender,
                    "latest_score": latest_score.score,
                    "previous_score": prev_score.score,
                    "diff": 0,
                    "category": "持平"
                })
    
    return {
        "progress_count": progress_count,
        "regression_count": regression_count,
        "stable_count": stable_count,
        "distribution": distribution,
        "latest_date": str(latest_exam_date),
        "previous_date": str(prev_exam_date)
    }


@router.get("/class/{class_id}/gender-distribution")
def get_gender_distribution(class_id: int, subject_id: Optional[int] = None, db: Session = Depends(get_db)):
    """Get gender distribution by score range bar chart data"""
    score_query = db.query(models.Score).filter(models.Score.class_id == class_id)
    if subject_id:
        score_query = score_query.filter(models.Score.subject_id == subject_id)
    
    latest_exam = score_query.order_by(models.Score.exam_date.desc()).first()
    if not latest_exam:
        return {"distribution": [], "exam_date": None}
    
    latest_date = latest_exam.exam_date
    
    # Get all scores for the latest exam with student info
    scores = db.query(models.Score, models.Student).join(
        models.Student, models.Score.student_id == models.Student.id
    ).filter(
        models.Score.class_id == class_id,
        models.Score.exam_date == latest_date
    )
    if subject_id:
        scores = scores.filter(models.Score.subject_id == subject_id)
    scores = scores.all()
    
    ranges = ["60分以下", "60-70分", "71-80分", "81-90分", "91-100分"]
    distribution = []
    
    for r in ranges:
        distribution.append({
            "range": r,
            "male": 0,
            "female": 0
        })
    
    for sc, student in scores:
        score = sc.score
        gender = student.gender
        if score < 60:
            idx = 0
        elif score <= 70:
            idx = 1
        elif score <= 80:
            idx = 2
        elif score <= 90:
            idx = 3
        else:
            idx = 4
        
        if gender == "男":
            distribution[idx]["male"] += 1
        else:
            distribution[idx]["female"] += 1
    
    return {"distribution": distribution, "exam_date": str(latest_date)}
