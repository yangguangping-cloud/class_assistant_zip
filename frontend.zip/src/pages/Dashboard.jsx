import { useState, useEffect, useCallback } from 'react'
import { Table, Button, Modal, Form, Select, message, Spin, Popconfirm } from 'antd'
import { ReloadOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons'
import { dashboardAPI, schedulesAPI, classesAPI, subjectsAPI } from '../services/api'
import { useAuth } from '../context/AuthContext'
import dayjs from 'dayjs'
import './Dashboard.css'

const timeSlots = [
  { key: '早自习', label: '早自习', time: '07:30-08:00' },
  { key: '上午1', label: '第1节', time: '08:00-08:45' },
  { key: '上午2', label: '第2节', time: '08:55-09:40' },
  { key: '上午3', label: '第3节', time: '10:00-10:45' },
  { key: '上午4', label: '第4节', time: '10:55-11:40' },
  { key: '午休', label: '午休', time: '11:40-14:00' },
  { key: '下午1', label: '第5节', time: '14:00-14:45' },
  { key: '下午2', label: '第6节', time: '14:55-15:40' },
  { key: '下午3', label: '第7节', time: '16:00-16:45' },
  { key: '下午4', label: '第8节', time: '16:55-17:40' },
  { key: '课后服务', label: '课后服务', time: '17:40-18:30' }
]

const weekDays = ['周一', '周二', '周三', '周四', '周五', '周六', '周日']

function Dashboard() {
  const [schedules, setSchedules] = useState([])
  const [loading, setLoading] = useState(false)
  const { user } = useAuth()
  const [currentTime, setCurrentTime] = useState(dayjs())
  const [modalVisible, setModalVisible] = useState(false)
  const [editingSlot, setEditingSlot] = useState(null) // { day, timeSlot, schedule }
  const [classes, setClasses] = useState([])
  const [subjects, setSubjects] = useState([])
  const [form] = Form.useForm()

  const fetchSchedules = useCallback(async () => {
    setLoading(true)
    try {
      const res = await dashboardAPI.getCurrentSchedule()
      const data = res.data
      if (Array.isArray(data)) {
        setSchedules(data)
      } else if (data && typeof data === 'object') {
        const allSchedules = [
          ...(data.upcoming || []),
          ...(data.ongoing || [])
        ]
        setSchedules(allSchedules)
      } else {
        setSchedules([])
      }
    } catch (err) {
      console.error('获取课程表失败:', err)
      message.error('获取课程表失败')
      setSchedules([])
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchSchedules()
    const timer = setInterval(fetchSchedules, 60000) // 1分钟刷新
    return () => clearInterval(timer)
  }, [fetchSchedules])

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(dayjs())
    }, 1000)
    return () => clearInterval(timer)
  }, [])

  useEffect(() => {
    classesAPI.list().then(res => setClasses(res.data))
    subjectsAPI.list().then(res => setSubjects(res.data))
  }, [])

  const getScheduleForSlot = (day, timeSlot) => {
    return schedules.find(s => s.day_of_week === day && s.time_slot === timeSlot)
  }

  const getCellClass = (day, schedule) => {
    if (!schedule) return 'schedule-cell editable'
    
    const now = currentTime
    const currentDay = now.day() // 0是周日，1-6是周一到周六
    const currentDayOfWeek = currentDay === 0 ? 6 : currentDay - 1 // 转换为0-6（周一到周日）
    
    // 检查是否是当天
    if (day !== currentDayOfWeek) {
      return 'schedule-cell'
    }
    
    const nowTime = now.format('HH:mm')
    
    // 检查是否是当前正在进行的课程
    if (schedule.start_time <= nowTime && nowTime <= schedule.end_time) {
      return 'schedule-cell ongoing'
    }
    
    // 检查是否是下一节课（当天，且在未来15分钟内）
    const startTime = dayjs(schedule.start_time, 'HH:mm')
    if (startTime.isAfter(now) && startTime.diff(now, 'minute') <= 15) {
      return 'schedule-cell upcoming'
    }
    
    return 'schedule-cell'
  }

  const handleCellClick = (day, timeSlot) => {
    const schedule = getScheduleForSlot(day, timeSlot)
    setEditingSlot({ day, timeSlot, schedule })
    if (schedule) {
      form.setFieldsValue({
        class_id: schedule.class_id,
        subject_id: schedule.subject_id
      })
    } else {
      form.resetFields()
      // Default to user's teaching subject
      if (user?.subject_id) {
        form.setFieldsValue({ subject_id: user.subject_id })
      }
    }
    setModalVisible(true)
  }

  const handleSave = async () => {
    const values = await form.validateFields()
    const timeSlotInfo = timeSlots.find(t => t.key === editingSlot.timeSlot)
    
    try {
      if (editingSlot.schedule) {
        // Update existing
        await schedulesAPI.update(editingSlot.schedule.id, {
          class_id: values.class_id,
          teacher_id: user.id,
          subject_id: values.subject_id,
          day_of_week: editingSlot.day,
          time_slot: editingSlot.timeSlot,
          start_time: timeSlotInfo.time.split('-')[0],
          end_time: timeSlotInfo.time.split('-')[1]
        })
        message.success('更新成功')
      } else {
        // Create new
        await schedulesAPI.create({
          class_id: values.class_id,
          teacher_id: user.id,
          subject_id: values.subject_id,
          day_of_week: editingSlot.day,
          time_slot: editingSlot.timeSlot,
          start_time: timeSlotInfo.time.split('-')[0],
          end_time: timeSlotInfo.time.split('-')[1]
        })
        message.success('添加成功')
      }
      setModalVisible(false)
      fetchSchedules()
    } catch (err) {
      console.error('保存失败:', err)
      message.error('保存失败')
    }
  }

  const handleDelete = async () => {
    if (!editingSlot.schedule) return
    try {
      await schedulesAPI.delete(editingSlot.schedule.id)
      message.success('删除成功')
      setModalVisible(false)
      fetchSchedules()
    } catch (err) {
      message.error('删除失败')
    }
  }

  const columns = [
    {
      title: '时间',
      dataIndex: 'time',
      key: 'time',
      width: 120,
      render: (text, record) => (
        <div>
          <div>{record.label}</div>
          <div style={{ fontSize: 12, color: '#999' }}>{record.time}</div>
        </div>
      )
    },
    ...weekDays.map((day, index) => ({
      title: day,
      key: index,
      render: (_, record) => {
        const schedule = getScheduleForSlot(index, record.key)
        return (
          <div 
            className={getCellClass(index, schedule)}
            onClick={() => handleCellClick(index, record.key)}
            style={{ cursor: 'pointer' }}
          >
            {schedule ? (
              <>
                <div>{schedule.class_name}</div>
                <div style={{ fontSize: 12 }}>{schedule.subject_name}</div>
              </>
            ) : (
              <span style={{ color: '#bbb' }}>+添加</span>
            )}
          </div>
        )
      }
    }))
  ]

  return (
    <div>
      <div style={{ marginBottom: 16, display: 'flex', justifyContent: 'space-between' }}>
        <h2>我的课程表</h2>
        <Button icon={<ReloadOutlined />} onClick={fetchSchedules} loading={loading}>
          刷新
        </Button>
      </div>
      <Spin spinning={loading}>
        <Table
          columns={columns}
          dataSource={timeSlots}
          rowKey="key"
          pagination={false}
          bordered
          size="middle"
        />
      </Spin>

      <Modal
        title={editingSlot?.schedule ? '编辑课程' : '添加课程'}
        open={modalVisible}
        onOk={handleSave}
        onCancel={() => setModalVisible(false)}
        footer={[
          editingSlot?.schedule && (
            <Popconfirm title="确定删除?" onConfirm={handleDelete}>
              <Button key="delete" icon={<DeleteOutlined />} danger>删除</Button>
            </Popconfirm>
          ),
          <Button key="cancel" onClick={() => setModalVisible(false)}>取消</Button>,
          <Button key="save" type="primary" onClick={handleSave}>保存</Button>
        ].filter(Boolean)}
      >
        <Form form={form} layout="vertical">
          <Form.Item name="class_id" label="班级" rules={[{ required: true }]}>
            <Select options={classes.map(c => ({ label: c.display_name, value: c.id }))} />
          </Form.Item>
          <Form.Item name="subject_id" label="学科" rules={[{ required: true }]}>
            <Select options={subjects.map(s => ({ label: s.name, value: s.id }))} />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  )
}

export default Dashboard
