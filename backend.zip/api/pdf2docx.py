from fastapi import APIRouter, HTTPException, UploadFile, File, BackgroundTasks
from fastapi.responses import FileResponse
import os
import uuid
from pdf2docx import Converter

router = APIRouter()

UPLOAD_DIR = "cache/uploads"
CONVERTED_DIR = "cache/converted"

# Create directories if they don't exist
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(CONVERTED_DIR, exist_ok=True)


@router.get("/health")
def health_check():
    """Health check endpoint"""
    return {"status": "ok", "service": "pdf2docx"}


@router.post("/convert")
async def convert_pdf_to_word(file: UploadFile = File(...)):
    """Convert PDF to Word document"""
    if not file.filename or not file.filename.lower().endswith('.pdf'):
        raise HTTPException(status_code=400, detail="只支持PDF格式文件")
    
    if file.size and file.size > 50 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="文件大小不能超过50MB")
    
    # Generate unique filenames
    pdf_id = str(uuid.uuid4())
    pdf_filename = f"{pdf_id}.pdf"
    word_filename = f"{pdf_id}.docx"
    
    pdf_path = os.path.join(UPLOAD_DIR, pdf_filename)
    word_path = os.path.join(CONVERTED_DIR, word_filename)
    
    try:
        # Save uploaded PDF
        content = await file.read()
        with open(pdf_path, 'wb') as f:
            f.write(content)
        
        # Convert PDF to Word
        cv = Converter(pdf_path)
        cv.convert(word_path)
        cv.close()
        
        # Return download info
        original_name = os.path.splitext(file.filename)[0]
        return {
            "filename": f"{original_name}.docx",
            "download_url": f"/api/pdf2docx/download/{word_filename}",
            "file_id": pdf_id
        }
    
    except Exception as e:
        # Clean up files on error
        if os.path.exists(pdf_path):
            os.remove(pdf_path)
        if os.path.exists(word_path):
            os.remove(word_path)
        raise HTTPException(status_code=500, detail=f"转换失败：{str(e)}")


def cleanup_files(file_paths):
    """清理临时文件"""
    for file_path in file_paths:
        try:
            if os.path.exists(file_path):
                os.remove(file_path)
        except Exception:
            pass


@router.delete("/clear-cache")
def clear_cache():
    """清空转换缓存文件"""
    deleted_count = 0
    errors = []
    
    # 清理converted目录
    if os.path.exists(CONVERTED_DIR):
        for filename in os.listdir(CONVERTED_DIR):
            file_path = os.path.join(CONVERTED_DIR, filename)
            try:
                if os.path.isfile(file_path):
                    os.remove(file_path)
                    deleted_count += 1
            except Exception as e:
                errors.append(f"删除 {filename} 失败: {str(e)}")
    
    # 清理uploads目录
    if os.path.exists(UPLOAD_DIR):
        for filename in os.listdir(UPLOAD_DIR):
            file_path = os.path.join(UPLOAD_DIR, filename)
            try:
                if os.path.isfile(file_path):
                    os.remove(file_path)
                    deleted_count += 1
            except Exception as e:
                errors.append(f"删除 {filename} 失败: {str(e)}")
    
    if errors:
        return {
            "message": f"已删除 {deleted_count} 个文件，{len(errors)} 个失败",
            "deleted_count": deleted_count,
            "errors": errors
        }
    
    return {
        "message": f"缓存清理完成，已删除 {deleted_count} 个文件",
        "deleted_count": deleted_count
    }


@router.get("/download/{filename}")
def download_word_file(filename: str, background_tasks: BackgroundTasks):
    """Download converted Word document"""
    file_path = os.path.join(CONVERTED_DIR, filename)
    
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="文件不存在")
    
    # 获取对应的PDF文件路径
    pdf_path = os.path.join(UPLOAD_DIR, filename.replace('.docx', '.pdf'))
    
    # 添加到后台任务，在响应发送后清理文件
    files_to_cleanup = [file_path]
    if os.path.exists(pdf_path):
        files_to_cleanup.append(pdf_path)
    
    background_tasks.add_task(cleanup_files, files_to_cleanup)
    
    return FileResponse(
        path=file_path,
        filename=filename,
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    )
