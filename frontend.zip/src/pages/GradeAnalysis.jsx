import { useState } from 'react'
import { Upload, Button, Table, message, Card, Statistic, Row, Col, Spin, Alert } from 'antd'
import { UploadOutlined, DownloadOutlined, ReloadOutlined, InboxOutlined } from '@ant-design/icons'
import { gradeAnalysisAPI } from '../services/api'
import './GradeAnalysis.css'

const { Dragger } = Upload

function GradeAnalysis() {
  const [scoreFile, setScoreFile] = useState(null)
  const [analysisFile, setAnalysisFile] = useState(null)
  const [loading, setLoading] = useState(false)
  const [analyzing, setAnalyzing] = useState(false)
  const [analysisResult, setAnalysisResult] = useState(null)
  const [error, setError] = useState(null)

  const handleScoreBeforeUpload = (file) => {
    setScoreFile(file)
    message.success(`${file.name} 已选择`)
    return false
  }

  const handleAnalysisBeforeUpload = (file) => {
    setAnalysisFile(file)
    message.success(`${file.name} 已选择`)
    return false
  }

  const handleAnalyze = async () => {
    if (!scoreFile || !analysisFile) {
      message.warning('请同时上传成绩表和试卷分析表')
      return
    }

    setAnalyzing(true)
    setError(null)

    try {
      const formData = new FormData()
      formData.append('score_file', scoreFile)
      formData.append('analysis_file', analysisFile)

      const response = await gradeAnalysisAPI.analyze(formData)
      setAnalysisResult(response.data)
      message.success(`分析完成！共处理 ${response.data.results.length} 个班级`)
    } catch (err) {
      const errorMsg = err.response?.data?.detail || '分析失败，请检查文件格式'
      setError(errorMsg)
      message.error(errorMsg)
    } finally {
      setAnalyzing(false)
    }
  }

  const handleExport = async () => {
    if (!analysisResult) {
      message.warning('请先进行分析')
      return
    }

    setLoading(true)
    try {
      const response = await gradeAnalysisAPI.export(analysisResult)
      
      // 创建下载链接
      const url = window.URL.createObjectURL(new Blob([response.data]))
      const link = document.createElement('a')
      link.href = url
      link.setAttribute('download', `试卷分析_${new Date().toISOString().slice(0, 10)}.xlsx`)
      document.body.appendChild(link)
      link.click()
      link.remove()
      window.URL.revokeObjectURL(url)
      
      message.success('导出成功！')
    } catch (err) {
      message.error('导出失败')
    } finally {
      setLoading(false)
    }
  }

  const handleReset = () => {
    setScoreFile(null)
    setAnalysisFile(null)
    setAnalysisResult(null)
    setError(null)
  }

  const columns = [
    { title: '班级', dataIndex: 'className', key: 'className', fixed: 'left' },
    { title: '教师', dataIndex: 'teacher', key: 'teacher' },
    { title: '参评人数', dataIndex: 'paramCount', key: 'paramCount' },
    { title: '优秀人数（85分及以上）', dataIndex: 'excellentCount', key: 'excellentCount' },
    {
      title: '优秀率',
      dataIndex: 'excellentRate',
      key: 'excellentRate',
      render: (val) => `${val.toFixed(2)}%`
    },
    { title: '及格人数（60分及以上）', dataIndex: 'passCount', key: 'passCount' },
    {
      title: '及格率',
      dataIndex: 'passRate',
      key: 'passRate',
      render: (val) => `${val.toFixed(2)}%`
    },
    { title: '不合格人数（60分以下）', dataIndex: 'failCount', key: 'failCount' },
    {
      title: '不合格率',
      dataIndex: 'failRate',
      key: 'failRate',
      render: (val) => `${val.toFixed(2)}%`
    },
    {
      title: '平均分',
      dataIndex: 'average',
      key: 'average',
      render: (val) => val.toFixed(2)
    },
    {
      title: '离均分值',
      dataIndex: 'deviation',
      key: 'deviation',
      render: (val) => {
        const color = val >= 0 ? '#28a745' : '#dc3545'
        const sign = val >= 0 ? '+' : ''
        return <span style={{ color, fontWeight: 'bold' }}>{sign}{val.toFixed(2)}</span>
      }
    },
    { title: '备注', dataIndex: 'remark', key: 'remark' }
  ]

  return (
    <div className="grade-analysis">
      <Card title="年级分析" className="header-card">
        <p>上传成绩表和试卷分析表，进行年级学习评价质量分析</p>
      </Card>

      <Card title="数据上传" className="upload-card">
        <Row gutter={[24, 24]}>
          <Col span={12}>
            <Dragger
              accept=".xlsx,.xls"
              beforeUpload={handleScoreBeforeUpload}
              maxCount={1}
              showUploadList={false}
            >
              {scoreFile ? (
                <div style={{ padding: '20px 0' }}>
                  <p className="ant-upload-drag-icon" style={{ marginBottom: 12 }}>
                    <InboxOutlined style={{ fontSize: 48, color: '#52c41a' }} />
                  </p>
                  <p style={{ fontSize: 16, fontWeight: 500, marginBottom: 8 }}>{scoreFile.name}</p>
                  <p className="ant-upload-hint">点击或拖拽替换文件</p>
                </div>
              ) : (
                <>
                  <p className="ant-upload-drag-icon">
                    <InboxOutlined />
                  </p>
                  <p className="ant-upload-text">导入级部成绩表</p>
                  <p className="ant-upload-hint">点击或拖拽上传 Excel 文件</p>
                </>
              )}
            </Dragger>
          </Col>
          <Col span={12}>
            <Dragger
              accept=".xlsx,.xls"
              beforeUpload={handleAnalysisBeforeUpload}
              maxCount={1}
              showUploadList={false}
            >
              {analysisFile ? (
                <div style={{ padding: '20px 0' }}>
                  <p className="ant-upload-drag-icon" style={{ marginBottom: 12 }}>
                    <InboxOutlined style={{ fontSize: 48, color: '#52c41a' }} />
                  </p>
                  <p style={{ fontSize: 16, fontWeight: 500, marginBottom: 8 }}>{analysisFile.name}</p>
                  <p className="ant-upload-hint">点击或拖拽替换文件</p>
                </div>
              ) : (
                <>
                  <p className="ant-upload-drag-icon">
                    <InboxOutlined />
                  </p>
                  <p className="ant-upload-text">导入试卷分析表</p>
                  <p className="ant-upload-hint">点击或拖拽上传 Excel 文件</p>
                </>
              )}
            </Dragger>
          </Col>
        </Row>

        <div className="action-buttons">
          <Button
            type="primary"
            icon={<UploadOutlined />}
            onClick={handleAnalyze}
            disabled={!scoreFile || !analysisFile || analyzing}
            loading={analyzing}
            size="large"
          >
            开始分析
          </Button>
          <Button
            type="primary"
            icon={<DownloadOutlined />}
            onClick={handleExport}
            disabled={!analysisResult}
            loading={loading}
            size="large"
          >
            导出分析结果
          </Button>
          <Button
            icon={<ReloadOutlined />}
            onClick={handleReset}
            size="large"
          >
            重置
          </Button>
        </div>
      </Card>

      {error && (
        <Alert
          message="分析失败"
          description={error}
          type="error"
          showIcon
          closable
          onClose={() => setError(null)}
          style={{ marginBottom: 24 }}
        />
      )}

      {analysisResult && (
        <>
          <Row gutter={[16, 16]} style={{ marginBottom: 24 }}>
            <Col span={8}>
              <Card>
                <Statistic
                  title="年级平均分"
                  value={analysisResult.gradeAverage}
                  precision={2}
                  suffix="分"
                />
              </Card>
            </Col>
            <Col span={8}>
              <Card>
                <Statistic
                  title="总参评人数"
                  value={analysisResult.totalStudents}
                  suffix="人"
                />
              </Card>
            </Col>
            <Col span={8}>
              <Card>
                <Statistic
                  title="班级数量"
                  value={analysisResult.classCount}
                  suffix="个"
                />
              </Card>
            </Col>
          </Row>

          <Card title="分析结果">
            <Table
              columns={columns}
              dataSource={analysisResult.results}
              rowKey="className"
              pagination={false}
              scroll={{ x: 1200 }}
              size="middle"
            />
            <div className="note">
              <strong>计算说明：</strong>
              <ol>
                <li>平均分：班级成绩的平均分（去掉一个最低分后计算）</li>
                <li>离均分值：班级平均分与年级平均分的差值（正数表示高于年级平均，负数表示低于年级平均）</li>
                <li>每个班级去掉一个最低分（缺考/请假按 0 分处理，也会被去掉）</li>
                <li>优秀率、及格率、不合格率均以去掉最低分后的参评人数为基数计算</li>
              </ol>
            </div>
          </Card>
        </>
      )}
    </div>
  )
}

export default GradeAnalysis
