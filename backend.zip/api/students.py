from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session
from typing import Optional
from datetime import datetime
from utils.database import get_db
from entity import models, schemas
from dateutil.relativedelta import relativedelta

router = APIRouter()


def calculate_age(birthday) -> int:
    """Calculate age from birthday"""
    today = datetime.now().date()
    return relativedelta(today, birthday).years


@router.get("")
def get_students(active: Optional[bool] = None, db: Session = Depends(get_db)):
    query = db.query(models.Student)
    if active is not None:
        query = query.filter(models.Student.active == active)
    students = query.all()
    result = []
    for s in students:
        tags = db.query(models.Tag).join(models.StudentTag).filter(
            models.StudentTag.student_id == s.id
        ).all()
        result.append({
            "id": s.id,
            "name": s.name,
            "gender": s.gender,
            "birthday": s.birthday,
            "age": s.age,
            "height": s.height,
            "weight": s.weight,
            "hobbies": s.hobbies,
            "friends": s.friends,
            "class_id": s.class_id,
            "active": s.active,
            "created_at": s.created_at,
            "tags": [{"id": t.id, "name": t.name, "created_at": t.created_at} for t in tags]
        })
    return result


@router.get("/{student_id}")
def get_student(student_id: int, db: Session = Depends(get_db)):
    student = db.query(models.Student).filter(models.Student.id == student_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    
    tags = db.query(models.Tag).join(models.StudentTag).filter(
        models.StudentTag.student_id == student.id
    ).all()
    
    return {
        "id": student.id,
        "name": student.name,
        "gender": student.gender,
        "birthday": student.birthday,
        "age": student.age,
        "height": student.height,
        "weight": student.weight,
        "hobbies": student.hobbies,
        "friends": student.friends,
        "class_id": student.class_id,
        "active": student.active,
        "created_at": student.created_at,
        "tags": [{"id": t.id, "name": t.name, "created_at": t.created_at} for t in tags]
    }


@router.post("", response_model=schemas.StudentResponse)
def create_student(student: schemas.StudentCreate, db: Session = Depends(get_db)):
    student_data = student.dict()
    # Calculate age from birthday
    if student_data.get('birthday'):
        student_data['age'] = calculate_age(student_data['birthday'])
    db_student = models.Student(**student_data)
    db.add(db_student)
    db.commit()
    db.refresh(db_student)
    return {
        "id": db_student.id,
        "name": db_student.name,
        "gender": db_student.gender,
        "birthday": db_student.birthday,
        "age": db_student.age,
        "height": db_student.height,
        "weight": db_student.weight,
        "hobbies": db_student.hobbies,
        "friends": db_student.friends,
        "class_id": db_student.class_id,
        "active": db_student.active,
        "created_at": db_student.created_at,
        "tags": []
    }


@router.put("/{student_id}", response_model=schemas.StudentResponse)
def update_student(student_id: int, student: schemas.StudentUpdate, db: Session = Depends(get_db)):
    db_student = db.query(models.Student).filter(models.Student.id == student_id).first()
    if not db_student:
        raise HTTPException(status_code=404, detail="Student not found")
    for key, value in student.dict().items():
        setattr(db_student, key, value)
    # Recalculate age if birthday changed
    if db_student.birthday:
        db_student.age = calculate_age(db_student.birthday)
    db.commit()
    db.refresh(db_student)
    
    tags = db.query(models.Tag).join(models.StudentTag).filter(
        models.StudentTag.student_id == db_student.id
    ).all()
    
    return {
        "id": db_student.id,
        "name": db_student.name,
        "gender": db_student.gender,
        "birthday": db_student.birthday,
        "age": db_student.age,
        "height": db_student.height,
        "weight": db_student.weight,
        "hobbies": db_student.hobbies,
        "friends": db_student.friends,
        "class_id": db_student.class_id,
        "active": db_student.active,
        "created_at": db_student.created_at,
        "tags": [{"id": t.id, "name": t.name, "created_at": t.created_at} for t in tags]
    }


@router.delete("/{student_id}")
def delete_student(student_id: int, db: Session = Depends(get_db)):
    db_student = db.query(models.Student).filter(models.Student.id == student_id).first()
    if not db_student:
        raise HTTPException(status_code=404, detail="Student not found")
    db.delete(db_student)
    db.commit()
    return {"message": "Student deleted"}


@router.post("/import")
async def import_students(file: UploadFile = File(...), db: Session = Depends(get_db)):
    """Import students from Excel file"""
    import pandas as pd
    import io
    
    try:
        content = await file.read()
        df = pd.read_excel(io.BytesIO(content))
        students = []
        for _, row in df.iterrows():
            birthday = row.get('生日')
            age = None
            if pd.notna(birthday):
                if isinstance(birthday, str):
                    birthday = datetime.strptime(birthday, '%Y-%m-%d').date()
                elif hasattr(birthday, 'date'):
                    birthday = birthday.date()
                age = calculate_age(birthday)
            else:
                birthday = None
            class_obj = db.query(models.Class).filter(
                models.Class.display_name == row["班级"]
            ).first()

            student = models.Student(
                name=row['姓名'],
                gender=row['性别'],
                birthday=birthday,
                age=age,
                height=row.get('身高(cm)', 0),
                weight=row.get('体重(kg)', 0),
                hobbies=row.get('爱好', ''),
                friends=row.get('朋友', ''),
                class_id=class_obj.id,
            )
            students.append(student)
        db.bulk_save_objects(students)
        db.commit()
        return {"message": f"Successfully imported {len(students)} students"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/promote")
def promote_students(db: Session = Depends(get_db)):
    """Promote all students to next grade (一年级->二年级, 六年级active改为False)"""
    # Get all grades
    grades = db.query(models.Grade).all()
    grade_map = {g.name: g for g in grades}
    
    # Define promotion mapping
    promotion_order = ["一年级", "二年级", "三年级", "四年级", "五年级", "六年级"]
    
    # Get all classes
    classes = db.query(models.Class).all()
    
    # Build target class mapping: old class_id -> new class_id
    target_class_map = {}
    sixth_grade_classes = []  # 六年级班级
    
    for c in classes:
        grade_name = c.grade.name if c.grade else ''
        if grade_name in promotion_order:
            idx = promotion_order.index(grade_name)
            # 六年级单独处理
            if idx == len(promotion_order) - 1:
                sixth_grade_classes.append(c.id)
            else:
                next_grade_name = promotion_order[idx + 1]
                next_grade = grade_map.get(next_grade_name)
                if next_grade:
                    # Find corresponding class in next grade
                    target_class = db.query(models.Class).filter(
                        models.Class.name == c.name,
                        models.Class.grade_id == next_grade.id
                    ).first()
                    if target_class:
                        target_class_map[c.id] = target_class.id
    
    # Update all students' class_id
    updated_count = 0
    deactivated_count = 0
    
    # 升级非六年级学生
    for old_class_id, new_class_id in target_class_map.items():
        students = db.query(models.Student).filter(
            models.Student.class_id == old_class_id
        ).all()
        for student in students:
            student.class_id = new_class_id
            updated_count += 1
    
    # 将六年级学生 active 设为 False
    for class_id in sixth_grade_classes:
        students = db.query(models.Student).filter(
            models.Student.class_id == class_id
        ).all()
        for student in students:
            student.active = False
            deactivated_count += 1
    
    db.commit()
    return {"message": f"Successfully promoted {updated_count} students, deactivated {deactivated_count} sixth-grade students"}
