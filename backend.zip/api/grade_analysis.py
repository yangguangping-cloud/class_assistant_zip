from fastapi import APIRouter, HTTPException, UploadFile, File
from fastapi.responses import StreamingResponse
import io
import openpyxl
from openpyxl.utils import get_column_letter

router = APIRouter()


def safe_str(val):
    """安全地将值转换为字符串，处理 None"""
    if val is None:
        return ''
    return str(val).strip()


def extract_class_scores_from_workbook(workbook):
    """从 workbook 对象中提取班级成绩数据（支持多 sheet）"""
    class_map = {}
    class_order = []
    
    for sheet_name in workbook.sheetnames:
        sheet = workbook[sheet_name]
        data = []
        for row in sheet.iter_rows(values_only=True):
            # 将 None 转换为空字符串
            data.append([safe_str(cell) for cell in row])
        
        header_row_idx = 0
        class_index = -1
        score_indices = []
        
        # 查找表头
        for row in range(min(10, len(data))):
            row_data = data[row] if row < len(data) else []
            for col in range(len(row_data)):
                cell = row_data[col]
                if '班级' in cell:
                    class_index = col
                if cell in ['语文', '数学', '英语', '科学', '道法', '品德', '综合', '总分', '成绩', '分数']:
                    score_indices.append(col)
            if class_index >= 0 and len(score_indices) > 0:
                header_row_idx = row
                break
        
        # 如果没找到班级列，使用第一列
        if class_index < 0:
            class_index = 0
        
        # 如果没找到分数列，使用最后一列（通常是成绩列）
        if len(score_indices) == 0:
            max_num_count = 0
            max_num_col = 1
            for col in range(1, 10):
                num_count = 0
                for row in range(header_row_idx + 1, min(header_row_idx + 20, len(data))):
                    val = data[row][col] if row < len(data) and col < len(data[row]) else ''
                    if val and val != '':
                        try:
                            float(val)
                            num_count += 1
                        except:
                            pass
                if num_count > max_num_count:
                    max_num_count = num_count
                    max_num_col = col
            score_indices = [max_num_col]
        
        # 提取学生成绩
        for row in range(header_row_idx + 1, len(data)):
            row_data = data[row] if row < len(data) else []
            class_name = row_data[class_index] if class_index < len(row_data) else ''
            
            # 跳过空行和表头
            if not class_name or '学号' in class_name or '姓名' in class_name:
                continue
            
            # 获取该学生的所有科目成绩
            scores = []
            for score_index in score_indices:
                score_val = row_data[score_index] if score_index < len(row_data) else ''
                if not score_val:
                    scores.append(0)
                else:
                    try:
                        score = float(score_val)
                        scores.append(score)
                    except:
                        scores.append(0)
            
            # 计算该学生的总分（所有科目之和）
            total_score = sum(scores)
            
            if class_name not in class_map:
                class_map[class_name] = []
            class_map[class_name].append(total_score)
        
        # 记录班级顺序（使用第一个学生的班级名称）
        first_class_name = ''
        for row in range(header_row_idx + 1, len(data)):
            row_data = data[row] if row < len(data) else []
            temp_class_name = row_data[class_index] if class_index < len(row_data) else ''
            if temp_class_name and '学号' not in temp_class_name and '姓名' not in temp_class_name:
                first_class_name = temp_class_name
                break
        if first_class_name and first_class_name in class_map and len(class_map[first_class_name]) > 0:
            class_order.append(first_class_name)
    
    return class_map, class_order


def calculate_statistics(class_scores, class_order, analysis_template):
    """计算各班级统计数据"""
    results = []
    total_sum = 0
    total_count = 0
    
    # 第一遍：计算年级总分和总人数（用于计算年级平均分）
    for class_name, scores in class_scores.items():
        # 去掉一个最低分
        sorted_scores = sorted(scores)
        if len(sorted_scores) > 1:
            sorted_scores = sorted_scores[1:]  # 去掉最低分
        
        class_sum = sum(sorted_scores)
        class_count = len(sorted_scores)
        
        total_sum += class_sum
        total_count += class_count
    
    # 计算年级平均分
    grade_average = total_sum / total_count if total_count > 0 else 0
    
    # 第二遍：按顺序计算每个班级的统计数据
    for i in range(len(class_order)):
        class_name = class_order[i]
        scores = class_scores.get(class_name, [])
        
        if not scores or len(scores) == 0:
            continue
        
        # 去掉一个最低分
        sorted_scores = sorted(scores)
        if len(sorted_scores) > 1:
            sorted_scores = sorted_scores[1:]  # 去掉最低分
        
        param_count = len(sorted_scores)  # 参评人数（去掉最低分后）
        
        # 统计各分数段人数
        excellent_count = 0  # 85 分及以上
        pass_count = 0       # 60 分及以上
        fail_count = 0       # 60 分以下
        
        for score in sorted_scores:
            if score >= 85:
                excellent_count += 1
            if score >= 60:
                pass_count += 1
            if score < 60:
                fail_count += 1
        
        # 计算比率
        excellent_rate = (excellent_count / param_count * 100) if param_count > 0 else 0
        pass_rate = (pass_count / param_count * 100) if param_count > 0 else 0
        fail_rate = (fail_count / param_count * 100) if param_count > 0 else 0
        
        # 计算平均分
        average = sum(sorted_scores) / param_count if param_count > 0 else 0
        
        # 计算离均差
        deviation = average - grade_average
        
        # 从模板中按顺序获取教师信息（使用索引匹配）
        teacher = ''
        if analysis_template:
            # 跳过表头行，从数据行开始匹配
            data_row_index = 0
            for row in analysis_template:
                row_data = row if isinstance(row, list) else [row]
                cell_value = safe_str(row_data[0] if len(row_data) > 0 else None)
                
                # 跳过标题行、表头行、空行和备注行
                if not cell_value or '班级' in cell_value or '每班' in cell_value or '学习评价' in cell_value:
                    continue
                
                # 找到第 i 个数据行
                if data_row_index == i:
                    teacher = safe_str(row_data[1] if len(row_data) > 1 else None)
                    break
                data_row_index += 1
        
        results.append({
            'className': class_name,
            'teacher': teacher,
            'paramCount': param_count,
            'excellentCount': excellent_count,
            'excellentRate': excellent_rate,
            'passCount': pass_count,
            'passRate': pass_rate,
            'failCount': fail_count,
            'failRate': fail_rate,
            'average': average,
            'deviation': deviation
        })
    
    return {
        'results': results,
        'gradeAverage': grade_average,
        'totalStudents': total_count,
        'classCount': len(class_order)
    }


@router.post("/analyze")
async def analyze_grade(
    score_file: UploadFile = File(...),
    analysis_file: UploadFile = File(...)
):
    """分析年级成绩"""
    try:
        score_content = await score_file.read()
        analysis_content = await analysis_file.read()
        
        score_wb = openpyxl.load_workbook(io.BytesIO(score_content))
        class_map, class_order = extract_class_scores_from_workbook(score_wb)
        
        analysis_wb = openpyxl.load_workbook(io.BytesIO(analysis_content))
        analysis_ws = analysis_wb.active
        analysis_template = []
        for row in analysis_ws.iter_rows(values_only=True):
            analysis_template.append([safe_str(cell) for cell in row])
        
        stats = calculate_statistics(class_map, class_order, analysis_template)
        
        # 返回模板数据用于导出
        stats['template'] = analysis_template
        
        return stats
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"分析失败：{str(e)}")


@router.post("/export")
async def export_grade_analysis(data: dict):
    """导出年级分析结果 - 填充到模板格式"""
    try:
        results = data.get('results', [])
        template_data = data.get('template', [])
        
        if not template_data:
            raise HTTPException(status_code=400, detail="缺少模板数据")
        
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "试卷分析"
        
        # 写入模板数据
        for row_idx, row_data in enumerate(template_data, 1):
            for col_idx, cell_value in enumerate(row_data, 1):
                ws.cell(row=row_idx, column=col_idx, value=cell_value)
        
        # 按顺序填充分析数据到模板中
        result_index = 0
        for row_idx, row_data in enumerate(template_data, 1):
            if row_idx > len(template_data):
                break
            
            first_cell = template_data[row_idx - 1][0] if len(template_data[row_idx - 1]) > 0 else None
            cell_value = safe_str(first_cell)
            
            # 跳过标题行、表头行、空行和备注行
            if not cell_value or '班级' in cell_value or '每班' in cell_value or '学习评价' in cell_value:
                continue
            
            # 按顺序获取分析结果并填充
            if result_index < len(results):
                result = results[result_index]
                
                # 填充数据到对应列 (从第3列开始，索引为2)
                # C列: 参评人数
                ws.cell(row=row_idx, column=3, value=result['paramCount'])
                # D列: 优秀人数
                ws.cell(row=row_idx, column=4, value=result['excellentCount'])
                # E列: 优秀率
                ws.cell(row=row_idx, column=5, value=f"{result['excellentRate']:.2f}%")
                # F列: 及格人数
                ws.cell(row=row_idx, column=6, value=result['passCount'])
                # G列: 及格率
                ws.cell(row=row_idx, column=7, value=f"{result['passRate']:.2f}%")
                # H列: 不合格人数
                ws.cell(row=row_idx, column=8, value=result['failCount'])
                # I列: 不合格率
                ws.cell(row=row_idx, column=9, value=f"{result['failRate']:.2f}%")
                # J列: 平均分
                ws.cell(row=row_idx, column=10, value=round(result['average'], 2))
                # K列: 离均分值
                deviation_sign = '+' if result['deviation'] >= 0 else ''
                ws.cell(row=row_idx, column=11, value=f"{deviation_sign}{result['deviation']:.2f}")
                
                result_index += 1
        
        # 设置列宽
        col_widths = [12, 12, 10, 12, 10, 12, 10, 12, 10, 10, 10, 15]
        for col_idx, width in enumerate(col_widths, 1):
            ws.column_dimensions[get_column_letter(col_idx)].width = width
        
        output = io.BytesIO()
        wb.save(output)
        output.seek(0)
        
        return StreamingResponse(
            io.BytesIO(output.read()),
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": "attachment; filename=grade_analysis.xlsx"}
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"导出失败：{str(e)}")
