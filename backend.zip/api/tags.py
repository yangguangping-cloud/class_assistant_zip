from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from utils.database import get_db
from entity import models, schemas

router = APIRouter()


@router.get("", response_model=List[schemas.TagResponse])
def get_tags(db: Session = Depends(get_db)):
    return db.query(models.Tag).all()


@router.post("", response_model=schemas.TagResponse)
def create_tag(tag: schemas.TagCreate, db: Session = Depends(get_db)):
    db_tag = models.Tag(**tag.dict())
    db.add(db_tag)
    db.commit()
    db.refresh(db_tag)
    return db_tag


@router.put("/{tag_id}", response_model=schemas.TagResponse)
def update_tag(tag_id: int, tag: schemas.TagUpdate, db: Session = Depends(get_db)):
    db_tag = db.query(models.Tag).filter(models.Tag.id == tag_id).first()
    if not db_tag:
        raise HTTPException(status_code=404, detail="Tag not found")
    db_tag.name = tag.name
    db.commit()
    db.refresh(db_tag)
    return db_tag


@router.delete("/{tag_id}")
def delete_tag(tag_id: int, db: Session = Depends(get_db)):
    db_tag = db.query(models.Tag).filter(models.Tag.id == tag_id).first()
    if not db_tag:
        raise HTTPException(status_code=404, detail="Tag not found")
    db.delete(db_tag)
    db.commit()
    return {"message": "Tag deleted"}


@router.post("/students/{student_id}/tags/{tag_id}")
def add_student_tag(student_id: int, tag_id: int, db: Session = Depends(get_db)):
    student_tag = models.StudentTag(student_id=student_id, tag_id=tag_id)
    db.add(student_tag)
    db.commit()
    return {"message": "Tag added"}


@router.delete("/students/{student_id}/tags/{tag_id}")
def remove_student_tag(student_id: int, tag_id: int, db: Session = Depends(get_db)):
    db.query(models.StudentTag).filter(
        models.StudentTag.student_id == student_id,
        models.StudentTag.tag_id == tag_id
    ).delete()
    db.commit()
    return {"message": "Tag removed"}
