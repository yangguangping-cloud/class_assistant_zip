import { useState, useEffect } from 'react'
import { Table, Button, Modal, Form, Input, Select, message, Popconfirm, Upload } from 'antd'
import { PlusOutlined, EditOutlined, DeleteOutlined, UploadOutlined } from '@ant-design/icons'

function CRUDManagement({ title, api, columns, formItems, children }) {
  const [data, setData] = useState([])
  const [loading, setLoading] = useState(false)
  const [modalVisible, setModalVisible] = useState(false)
  const [editingItem, setEditingItem] = useState(null)
  const [form] = Form.useForm()

  const fetchData = async () => {
    setLoading(true)
    try {
      const res = await api.list()
      setData(res.data)
    } catch (err) {
      message.error('获取数据失败')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchData() }, [])

  const handleSubmit = async () => {
    const values = await form.validateFields()
    try {
      if (editingItem) {
        await api.update(editingItem.id, values)
        message.success('更新成功')
      } else {
        await api.create(values)
        message.success('创建成功')
      }
      setModalVisible(false)
      fetchData()
    } catch (err) {
      message.error('操作失败')
    }
  }

  const handleDelete = async (id) => {
    try {
      await api.delete(id)
      message.success('删除成功')
      fetchData()
    } catch (err) {
      message.error('删除失败')
    }
  }

  const defaultColumns = [
    ...columns,
    {
      title: '操作',
      key: 'action',
      render: (_, record) => (
        <>
          <Button icon={<EditOutlined />} onClick={() => { setEditingItem(record); form.setFieldsValue(record); setModalVisible(true) }} />
          <Popconfirm title="确定删除?" onConfirm={() => handleDelete(record.id)}>
            <Button icon={<DeleteOutlined />} danger style={{ marginLeft: 8 }} />
          </Popconfirm>
        </>
      )
    }
  ]

  return (
    <div>
      <Button type="primary" icon={<PlusOutlined />} onClick={() => { setEditingItem(null); form.resetFields(); setModalVisible(true) }}>
        新增{title}
      </Button>
      {children}
      <Table columns={defaultColumns} dataSource={data} rowKey="id" loading={loading} style={{ marginTop: 16 }} />
      <Modal title={editingItem ? `编辑${title}` : `新增${title}`} open={modalVisible} onOk={handleSubmit} onCancel={() => setModalVisible(false)}>
        <Form form={form} layout="vertical" initialValues={editingItem || {}}>
          {formItems}
        </Form>
      </Modal>
    </div>
  )
}

export default CRUDManagement
