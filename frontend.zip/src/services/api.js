import axios from 'axios'

const API_BASE = 'http://localhost:8000/api'

export const api = axios.create({
  baseURL: API_BASE,
  headers: {
    'Content-Type': 'application/json'
  }
})

// Add token interceptor
api.interceptors.request.use(config => {
  const token = localStorage.getItem('token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// CRUD helper
export const createCRUD = (resource) => ({
  list: (config) => api.get(`/${resource}`, config),
  get: (id) => api.get(`/${resource}/${id}`),
  create: (data) => api.post(`/${resource}`, data),
  update: (id, data) => api.put(`/${resource}/${id}`, data),
  delete: (id) => api.delete(`/${resource}/${id}`)
})

export const gradesAPI = createCRUD('grades')
export const subjectsAPI = createCRUD('subjects')
export const classesAPI = {
  ...createCRUD('classes'),
  getTeacherClasses: (teacherId) => api.get(`/classes/teacher/${teacherId}`)
}
export const usersAPI = createCRUD('users')
export const studentsAPI = {
  ...createCRUD('students'),
  import: (formData) => api.post('/students/import', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  }),
  promote: () => api.post('/students/promote')
}
export const tagsAPI = createCRUD('tags')
export const schedulesAPI = createCRUD('schedules')

export const scoresAPI = {
  list: () => api.get('/scores'),
  getByStudent: (studentId) => api.get(`/scores/student/${studentId}`),
  getByClass: (classId, subjectId) => api.get(`/scores/class/${classId}/subject/${subjectId}`),
  create: (data) => api.post('/scores', data),
  update: (id, data) => api.put(`/scores/${id}`, data),
  delete: (id) => api.delete(`/scores/${id}`),
  import: (file) => {
    const formData = new FormData()
    formData.append('file', file)
    return api.post('/scores/import', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    })
  }
}

export const studentTagsAPI = {
  add: (studentId, tagId) => api.post(`/students/${studentId}/tags/${tagId}`),
  remove: (studentId, tagId) => api.delete(`/students/${studentId}/tags/${tagId}`)
}

export const dashboardAPI = {
  getClassInfo: (classId, subjectId) => api.get(`/dashboard/class/${classId}`, {
    params: { subject_id: subjectId }
  }),
  getClassAvgScore: (classId, subjectId) => api.get(`/dashboard/class/${classId}/average-score`, {
    params: { subject_id: subjectId }
  }),
  getStudentScores: (studentId, subjectId) => api.get(`/dashboard/student/${studentId}/scores`, {
    params: { subject_id: subjectId }
  }),
  getClassStudents: (classId, subjectId) => api.get(`/dashboard/class/${classId}/students`, {
    params: { subject_id: subjectId }
  }),
  getProgressReport: (classId, subjectId) => api.get(`/dashboard/class/${classId}/progress-report`, {
    params: { subject_id: subjectId }
  }),
  getRegressionReport: (classId, subjectId) => api.get(`/dashboard/class/${classId}/regression-report`, {
    params: { subject_id: subjectId }
  }),
  getScoreDistribution: (classId, subjectId) => api.get(`/dashboard/class/${classId}/score-distribution`, {
    params: { subject_id: subjectId }
  }),
  getGenderDistribution: (classId, subjectId) => api.get(`/dashboard/class/${classId}/gender-distribution`, {
    params: { subject_id: subjectId }
  }),
  getProgressRegressionSummary: (classId, subjectId) => api.get(`/dashboard/class/${classId}/progress-regression-summary`, {
    params: { subject_id: subjectId }
  }),
  getCurrentSchedule: () => api.get('/dashboard/current-schedule')
}

export const seedAPI = () => api.post('/seed')

export const gradeAnalysisAPI = {
  analyze: (formData) => api.post('/grade-analysis/analyze', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  }),
  export: (data) => api.post('/grade-analysis/export', data, {
    responseType: 'blob'
  })
}
