import { Routes, Route, useNavigate, useLocation } from 'react-router-dom'
import { Menu } from 'antd'
import {
  BookOutlined,
  TeamOutlined,
  UserOutlined,
  TrophyOutlined,
  TagsOutlined,
  ReadOutlined
} from '@ant-design/icons'
import GradeManagement from './management/GradeManagement'
import ClassManagement from './management/ClassManagement'
import StudentManagement from './management/StudentManagement'
import UserManagement from './management/UserManagement'
import ScoreManagement from './management/ScoreManagement'
import TagManagement from './management/TagManagement'
import './Management.css'

const menuItems = [
  { key: '/management/grades', icon: <ReadOutlined />, label: '年级管理' },
  { key: '/management/classes', icon: <TeamOutlined />, label: '班级管理' },
  { key: '/management/students', icon: <UserOutlined />, label: '学生管理' },
  { key: '/management/users', icon: <BookOutlined />, label: '用户管理' },
  { key: '/management/scores', icon: <TrophyOutlined />, label: '成绩管理' },
  { key: '/management/tags', icon: <TagsOutlined />, label: '标签管理' }
]

function Management() {
  const navigate = useNavigate()
  const location = useLocation()

  return (
    <div className="management-container">
      <Menu
        mode="horizontal"
        selectedKeys={[location.pathname]}
        items={menuItems}
        onClick={({ key }) => navigate(key)}
        style={{ marginBottom: 16 }}
      />
      <Routes>
        <Route index element={<GradeManagement />} />
        <Route path="grades" element={<GradeManagement />} />
        <Route path="classes" element={<ClassManagement />} />
        <Route path="students" element={<StudentManagement />} />
        <Route path="users" element={<UserManagement />} />
        <Route path="scores" element={<ScoreManagement />} />
        <Route path="tags" element={<TagManagement />} />
      </Routes>
    </div>
  )
}

export default Management
