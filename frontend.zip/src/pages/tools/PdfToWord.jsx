import { useState, useEffect } from 'react'
import { Upload, Button, Progress, message, Card, Typography, Space, Table, Tag, Popconfirm } from 'antd'
import {
  InboxOutlined,
  FilePdfOutlined,
  FileWordOutlined,
  ReloadOutlined,
  CheckCircleOutlined,
  CloseCircleOutlined,
  DownloadOutlined,
  DeleteOutlined
} from '@ant-design/icons'
import axios from 'axios'

const { Dragger } = Upload
const { Title, Text } = Typography

const API_BASE_URL = 'http://localhost:8000'

function PdfToWord() {
  const [fileList, setFileList] = useState([])
  const [converting, setConverting] = useState(false)
  const [serverOnline, setServerOnline] = useState(false)

  // Check server connection
  useEffect(() => {
    checkServerConnection()
  }, [])

  const checkServerConnection = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/api/pdf2docx/health`)
      if (response.data.status === 'ok') {
        setServerOnline(true)
      }
    } catch (error) {
      setServerOnline(false)
    }
  }

  const handleFileChange = ({ fileList: newFileList }) => {
    // Validate and update file list
    const validatedFiles = newFileList.map(file => {
      // Check if file is PDF
      if (!file.name.toLowerCase().endsWith('.pdf')) {
        message.error(`${file.name} 不是PDF格式文件`)
        return { ...file, status: 'error', error: '格式不支持' }
      }
      // Check file size (50MB)
      if (file.size && file.size > 50 * 1024 * 1024) {
        message.error(`${file.name} 文件大小超过50MB`)
        return { ...file, status: 'error', error: '文件过大' }
      }
      return file
    }).filter(file => file.status !== 'error' || file.originFileObj)

    setFileList(validatedFiles)
  }

  const convertAllPDF = async () => {
    // 过滤出有原始文件对象且未转换的文件
    const pdfFiles = fileList.filter(f => f.originFileObj && !f.converted && f.status !== 'error')
    
    if (pdfFiles.length === 0) {
      message.error('请先上传PDF文件')
      return
    }

    if (!serverOnline) {
      message.error('服务器未连接！请检查后端服务是否启动')
      return
    }

    setConverting(true)

    try {
      // 使用最新的fileList副本
      let currentFileList = [...fileList]
      
      // Process files one by one
      for (let i = 0; i < currentFileList.length; i++) {
        const fileItem = currentFileList[i]
        
        if (!fileItem.originFileObj || fileItem.converted) continue

        // Update status to converting
        currentFileList[i] = { ...currentFileList[i], status: 'uploading', progress: 0 }
        setFileList([...currentFileList])

        let progressTimer = null
        try {
          const formData = new FormData()
          formData.append('file', fileItem.originFileObj)

          // 启动进度更新定时器
          let progressValue = 0
          progressTimer = setInterval(() => {
            // 进度从0逐渐增加到95%（等待服务器响应）
            if (progressValue < 95) {
              progressValue = Math.min(progressValue + 2, 95)
              currentFileList[i] = { ...currentFileList[i], progress: progressValue }
              setFileList([...currentFileList])
            }
          }, 200)

          const response = await axios.post(`${API_BASE_URL}/api/pdf2docx/convert`, formData, {
            headers: {
              'Content-Type': 'multipart/form-data'
            }
          })

          // 清除定时器，设置100%
          clearInterval(progressTimer)
          currentFileList[i] = {
            ...currentFileList[i],
            status: 'done',
            progress: 100,
            converted: true,
            downloadUrl: response.data.download_url,
            filename: response.data.filename,
            fileId: response.data.file_id
          }
          setFileList([...currentFileList])
          message.success(`${fileItem.name} 转换成功`)

        } catch (error) {
          console.error(`Conversion error for ${fileItem.name}:`, error)
          if (progressTimer) clearInterval(progressTimer)
          currentFileList[i] = {
            ...currentFileList[i],
            status: 'error',
            progress: 0,
            error: error.response?.data?.detail || error.message
          }
          setFileList([...currentFileList])
          message.error(`${fileItem.name} 转换失败`)
        }
      }

      message.success('所有文件转换完成')
    } catch (error) {
      message.error('批量转换过程中出现错误')
    } finally {
      setConverting(false)
    }
  }

  const downloadFile = async (fileItem) => {
    try {
      const response = await axios.get(`${API_BASE_URL}${fileItem.downloadUrl}`, {
        responseType: 'blob'
      })

      // Create download link
      const url = window.URL.createObjectURL(new Blob([response.data]))
      const link = document.createElement('a')
      link.href = url
      link.setAttribute('download', fileItem.filename)
      document.body.appendChild(link)
      link.click()
      link.remove()
      window.URL.revokeObjectURL(url)

      message.success(`${fileItem.filename} 下载成功`)
    } catch (error) {
      message.error('下载失败')
    }
  }

  const downloadAllConverted = async () => {
    const convertedFiles = fileList.filter(f => f.converted && f.downloadUrl)
    
    if (convertedFiles.length === 0) {
      message.warning('没有可下载的文件')
      return
    }

    for (const fileItem of convertedFiles) {
      await downloadFile(fileItem)
      // Small delay between downloads
      await new Promise(resolve => setTimeout(resolve, 500))
    }

    message.success('所有文件下载完成')
  }

  const resetAll = () => {
    setFileList([])
    setConverting(false)
  }

  const clearCache = async () => {
    try {
      const response = await axios.delete(`${API_BASE_URL}/api/pdf2docx/clear-cache`)
      message.success(response.data.message)
    } catch (error) {
      message.error('缓存清理失败')
    }
  }

  const columns = [
    {
      title: '文件名',
      dataIndex: 'name',
      key: 'name',
      render: (text) => (
        <Space>
          <FilePdfOutlined style={{ color: '#ff4d4f' }} />
          <Text>{text}</Text>
        </Space>
      )
    },
    {
      title: '大小',
      dataIndex: 'size',
      key: 'size',
      render: (size) => size ? `${(size / 1024 / 1024).toFixed(2)} MB` : '-'
    },
    {
      title: '状态',
      key: 'status',
      render: (_, record) => {
        if (record.status === 'uploading') {
          return (
            <Space orientation="vertical" size={0}>
              <Tag color="processing">转换中</Tag>
              <Progress percent={record.progress || 0} size="small" />
            </Space>
          )
        }
        if (record.converted) {
          return <Tag icon={<CheckCircleOutlined />} color="success">转换成功</Tag>
        }
        if (record.status === 'error') {
          return (
            <Space orientation="vertical" size={0}>
              <Tag icon={<CloseCircleOutlined />} color="error">转换失败</Tag>
              {record.error && <Text type="danger" style={{ fontSize: 12 }}>{record.error}</Text>}
            </Space>
          )
        }
        return <Tag color="default">等待转换</Tag>
      }
    },
    {
      title: '操作',
      key: 'action',
      render: (_, record) => (
        <Button
          type="link"
          icon={<DownloadOutlined />}
          disabled={!record.converted || !record.downloadUrl}
          onClick={() => downloadFile(record)}
        >
          下载
        </Button>
      )
    }
  ]

  const uploadProps = {
    multiple: true,
    accept: '.pdf',
    fileList,
    onChange: handleFileChange,
    beforeUpload: () => false, // Prevent auto upload
    showUploadList: false
  }

  const convertedCount = fileList.filter(f => f.converted).length
  const totalCount = fileList.length

  return (
    <div style={{ padding: '24px' }}>
      <Card
        extra={
          <Popconfirm
            title="确认清空缓存"
            description="将删除所有已转换的临时文件，确定继续？"
            onConfirm={clearCache}
            okText="确定"
            cancelText="取消"
          >
            <Button
              danger
              size="small"
              icon={<DeleteOutlined />}
            >
              清空缓存
            </Button>
          </Popconfirm>
        }
      >
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <Title level={2}>
            <FilePdfOutlined style={{ color: '#ff4d4f', marginRight: 8 }} />
            PDF转Word转换器 - 批量版
          </Title>
          <Text type="secondary">
            使用pdf2docx引擎，支持批量转换，完美保留格式、图片、表格
          </Text>
        </div>

        {/* Server Status */}
        <div style={{
          padding: '8px 16px',
          background: serverOnline ? '#f6ffed' : '#fff2f0',
          borderRadius: 4,
          marginBottom: 24,
          textAlign: 'center'
        }}>
          {serverOnline ? (
            <Space>
              <CheckCircleOutlined style={{ color: '#52c41a' }} />
              <Text type="success">服务器连接正常</Text>
            </Space>
          ) : (
            <Space>
              <CloseCircleOutlined style={{ color: '#ff4d4f' }} />
              <Text type="danger">服务器未启动，请检查后端服务</Text>
            </Space>
          )}
        </div>

        {/* Upload Area */}
        <Dragger {...uploadProps}>
          <p className="ant-upload-drag-icon">
            <InboxOutlined style={{ fontSize: 64, color: '#1890ff' }} />
          </p>
          <p style={{ fontSize: 18, color: '#333', marginBottom: 8 }}>
            点击或拖拽PDF文件到此处（支持批量上传）
          </p>
          <p style={{ color: '#666', fontSize: 14 }}>
            支持PDF格式，单个文件最大50MB
          </p>
        </Dragger>

        {/* Action Buttons */}
        {totalCount > 0 && (
          <div style={{ textAlign: 'center', margin: '24px 0' }}>
            <Space size="middle">
              <Button
                type="primary"
                size="large"
                icon={<FileWordOutlined />}
                onClick={convertAllPDF}
                disabled={totalCount === 0 || converting}
                loading={converting}
              >
                {converting ? '转换中...' : `开始转换 (${totalCount}个文件)`}
              </Button>
              <Button
                type="primary"
                size="large"
                icon={<DownloadOutlined />}
                onClick={downloadAllConverted}
                disabled={convertedCount === 0}
              >
                批量下载 ({convertedCount}个文件)
              </Button>
              <Button
                size="large"
                icon={<ReloadOutlined />}
                onClick={resetAll}
              >
                重置
              </Button>
            </Space>
          </div>
        )}



        {/* File List Table */}
        {totalCount > 0 && (
          <Card size="small" style={{ marginTop: 24 }}>
            <Table
              columns={columns}
              dataSource={fileList}
              rowKey="uid"
              pagination={false}
              size="middle"
            />
          </Card>
        )}

        {/* Instructions */}
        <Card
          size="small"
          style={{
            marginTop: 24,
            background: '#fffbe6',
            borderColor: '#ffe58f'
          }}
        >
          <Title level={5} style={{ marginBottom: 12 }}>
            📌 使用说明：
          </Title>
          <ul style={{ marginLeft: 20, marginBottom: 0 }}>
            <li>需要启动Python后端服务（运行 backend/main.py）</li>
            <li>使用pdf2docx引擎，完美保留PDF格式、图片、表格</li>
            <li>支持批量上传和转换，单个文件最大50MB</li>
            <li>转换过程在服务器端完成，文件不会永久保存</li>
          </ul>
        </Card>
      </Card>
    </div>
  )
}

export default PdfToWord
