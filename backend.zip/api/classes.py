from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from utils.database import get_db
from entity import models, schemas

router = APIRouter()


@router.get("")
def get_classes(db: Session = Depends(get_db)):
    classes = db.query(models.Class).all()
    result = []
    for c in classes:
        grade_name = c.grade.name[0] if c.grade else ''
        display_name = c.display_name if c.display_name else f"{grade_name}{c.name}"
        result.append({
            "id": c.id,
            "name": c.name,
            "display_name": display_name,
            "grade_id": c.grade_id,
            "teacher_id": c.teacher_id,
            "created_at": c.created_at
        })
    result.sort(key=lambda x: x["display_name"])
    return result


@router.get("/teacher/{teacher_id}")
def get_teacher_classes(teacher_id: int, db: Session = Depends(get_db)):
    """Get classes taught by a specific teacher, grouped by grade"""
    classes = db.query(models.Class).filter(models.Class.teacher_id == teacher_id).all()
    result = []
    for c in classes:
        grade_name = c.grade.name[0] if c.grade else ''
        display_name = c.display_name if c.display_name else f"{grade_name}{c.name}"
        result.append({
            "id": c.id,
            "name": c.name,
            "display_name": display_name,
            "grade_id": c.grade_id,
            "grade_name": grade_name,
            "teacher_id": c.teacher_id,
            "created_at": c.created_at
        })
    result.sort(key=lambda x: x["display_name"])
    return result


@router.post("", response_model=schemas.ClassResponse)
def create_class(class_item: schemas.ClassCreate, db: Session = Depends(get_db)):
    grade = db.query(models.Grade).filter(models.Grade.id == class_item.grade_id).first()
    grade_name = grade.name[0] if grade else ''
    del class_item.display_name
    db_class = models.Class(
        **class_item.dict(),
        display_name=f"{grade_name}{class_item.name}"
    )
    db.add(db_class)
    db.commit()
    db.refresh(db_class)
    return db_class


@router.put("/{class_id}", response_model=schemas.ClassResponse)
def update_class(class_id: int, class_item: schemas.ClassUpdate, db: Session = Depends(get_db)):
    db_class = db.query(models.Class).filter(models.Class.id == class_id).first()
    if not db_class:
        raise HTTPException(status_code=404, detail="Class not found")
    for key, value in class_item.dict().items():
        setattr(db_class, key, value)
    # Regenerate display_name if name or grade_id changed
    grade = db.query(models.Grade).filter(models.Grade.id == db_class.grade_id).first()
    grade_name = grade.name[0] if grade else ''
    db_class.display_name = f"{grade_name}{db_class.name}"
    db.commit()
    db.refresh(db_class)
    return db_class


@router.delete("/{class_id}")
def delete_class(class_id: int, db: Session = Depends(get_db)):
    db_class = db.query(models.Class).filter(models.Class.id == class_id).first()
    if not db_class:
        raise HTTPException(status_code=404, detail="Class not found")
    db.delete(db_class)
    db.commit()
    return {"message": "Class deleted"}
