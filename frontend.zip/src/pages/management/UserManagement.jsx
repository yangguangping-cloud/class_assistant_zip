import { useState, useEffect } from 'react'
import { Table, Button, Modal, Form, Input, Select, message, Popconfirm } from 'antd'
import { PlusOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons'
import { usersAPI, subjectsAPI } from '../../services/api'

function UserManagement() {
  const [data, setData] = useState([])
  const [subjects, setSubjects] = useState([])
  const [loading, setLoading] = useState(false)
  const [modalVisible, setModalVisible] = useState(false)
  const [editingItem, setEditingItem] = useState(null)
  const [form] = Form.useForm()

  const fetchData = async () => {
    setLoading(true)
    try {
      const [usersRes, subjectsRes] = await Promise.all([usersAPI.list(), subjectsAPI.list()])
      setData(usersRes.data)
      setSubjects(subjectsRes.data)
    } catch (err) {
      message.error('获取数据失败')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchData() }, [])

  const handleSubmit = async () => {
    const values = await form.validateFields()
    try {
      if (editingItem) {
        await usersAPI.update(editingItem.id, values)
      } else {
        await usersAPI.create(values)
      }
      message.success('操作成功')
      setModalVisible(false)
      fetchData()
    } catch (err) {
      message.error('操作失败')
    }
  }

  const handleDelete = async (id) => {
    try {
      await usersAPI.delete(id)
      message.success('删除成功')
      fetchData()
    } catch (err) {
      message.error('删除失败')
    }
  }

  const getSubjectName = (id) => subjects.find(s => s.id === id)?.name || '-'

  const columns = [
    { title: 'ID', dataIndex: 'id', key: 'id' },
    { title: '用户名', dataIndex: 'username', key: 'username' },
    { title: '姓名', dataIndex: 'name', key: 'name' },
    { title: '学科', dataIndex: 'subject_id', key: 'subject_id', render: getSubjectName },
    { title: '角色', dataIndex: 'role', key: 'role' },
    {
      title: '操作', key: 'action', render: (_, record) => (
        <>
          <Button icon={<EditOutlined />} onClick={() => { setEditingItem(record); form.setFieldsValue(record); setModalVisible(true) }} />
          <Popconfirm title="确定删除?" onConfirm={() => handleDelete(record.id)}>
            <Button icon={<DeleteOutlined />} danger style={{ marginLeft: 8 }} />
          </Popconfirm>
        </>
      )
    }
  ]

  return (
    <div>
      <Button type="primary" icon={<PlusOutlined />} onClick={() => { setEditingItem(null); form.resetFields(); setModalVisible(true) }}>
        新增用户
      </Button>
      <Table columns={columns} dataSource={data} rowKey="id" loading={loading} style={{ marginTop: 16 }} />
      <Modal title={editingItem ? '编辑用户' : '新增用户'} open={modalVisible} onOk={handleSubmit} onCancel={() => setModalVisible(false)}>
        <Form form={form} layout="vertical">
          <Form.Item name="username" label="用户名" rules={[{ required: true }]}><Input /></Form.Item>
          <Form.Item name="name" label="姓名" rules={[{ required: true }]}><Input /></Form.Item>
          <Form.Item name="password" label="密码" rules={editingItem ? [] : [{ required: true }]}><Input.Password /></Form.Item>
          <Form.Item name="subject_id" label="学科">
            <Select options={subjects.map(s => ({ label: s.name, value: s.id }))} />
          </Form.Item>
          <Form.Item name="role" label="角色" rules={[{ required: true }]}>
            <Select options={[{ label: '老师', value: 'teacher' }, { label: '管理员', value: 'admin' }]} />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  )
}

export default UserManagement
